# Vigilant bet history (everything)

Generated 2026-10-13T02:06:56.46-04:00 by Vigilant (format 1). **1648 bets and bid fills** (373 are bid fills), **37117 bids posted**, from 2026-09-25 to 2026-10-13.

## Your task
Tj bets on Novig (a US exchange) with a +EV scanner, **Vigilant**. The goal is PROFIT through positive EV that the CLOSING LINE confirms. From the files below find (1) which kinds of bets and bids beat the close and are
profitable and which do not, (2) whether the app's own star rating, sharp-book check and agreement counts predict beating the close, (3) specific filters, thresholds and rule changes for the auto-bet
and the auto-bid desk (name the setting or the code: Presets.kt, SharpVeto.kt, AutoBet.kt, MakerRules.kt, BetRating.kt), (4) data-quality problems in the logging itself. Judge groups by CLV first (it needs far fewer
bets than profit to say anything): a group wants roughly 100+ bets with a true close before CLV means much and 1,000+ before ROI does. State the sample size and t-statistic behind every claim, say when the sample is too small, and
do not recommend a change on a handful of bets. Bets and bids are different instruments (a bid can be picked off; a bet cannot): read them apart.

## Files
- `vigilant-bets-2026-10-13-all-bets-p1.jsonl`: bets and bid fills, one JSON object per line, oldest first
- `vigilant-bets-2026-10-13-all-bids-posted-p1.jsonl`: every bid posted (filled or not), one JSON object per line
- this README: dictionary, definitions, summary tables and automatic findings

## Definitions
- **Odds** are American. `cost` is the price paid per $1 of payout including Novig's taker fee (a pregame taker fee is 0; a bid pays no fee). EV, CLV, ROI, fair and win % are fractions (0.03 = +3%).
- **EV** (`ev`): `fair / cost - 1` at the moment of placing, against the fair chance the app had then (devigged books). For a bid it is the edge at its fair when it was POSTED.
- **Fair** (`fair`, `fairOdds`): the no-vig chance of the bet's side from the books (worst-case devig, lower of mean and median; sister sites count once; books with wrong-looking odds are left out).
- **Close and CLV**: `closeFair` is the same side's no-vig chance at the START of the game; `closeOdds` is that as American odds (a fair price, not a book price: do not compare it with `odds` without the vig in mind - `clv` already does). `clv = closeFair / cost - 1`:
  positive = the bet was cheaper than the market's final opinion. It exists ONLY for a TRUE close: a read of the market in the last 15 minutes before the start made at least 60 s after the bet (a read seconds after the bet is its own line, not a close), or a history source's price at the start. `closeSource` = captured or the history source.
  `closeBasis` says what the close is made of: `read:cno` (CrazyNinjaOdds' consensus, the SAME kind of consensus that found most CNO bets), `read:vigilant` (Vigilant's own fair line), `read:both`, `history:pinnacle` (Pinnacle's price at the start, via ParlayAPI/SGO/OddsPapi), `history:espn`, `history:novig-trades` (the last 3+ trades on Novig in the last 15 minutes, the bettor's own fills included).
  `closeIndependent` = true only for history from another source than the one that found the bet (a sharp book's price at the start, or ESPN's): CLV against `read:cno` is partly circular (the bet and its close come from one consensus), so **test every CLV claim on `closeIndependent: true` bets too**. When both exist the sharp book's price at the start is the close (the app asks for it even when a read before the start exists); `startsLoggedMs`/`startsNote` appear when a game started early or late and the start was corrected. For a read, `closeReadMs`/`closeLeadSec` say when it was taken and how many seconds before the start, `closeReadAfterBetSec` how long after the bet; a history close has no read time (it is the price at the start).
  Closes found after the game are devigged by the same conservative WORST-CASE method as the app's own fair (the lowest fair chance of four methods; `AtBet`'s `fairMethod` says which method priced each bet: bets before v0.89.19 used POWER); before v0.89.18 history closes were multiplicative, which flatters longshots by 5-13% (so very old history closes on dogs are biased high). `novigCloseOdds`/`novigCloseAgeSec` = Novig's own last price when it was read in the last 15 minutes before the start.
- **Stars** (`stars`, 1-5 in halves): the app's rating of how much to TRUST the edge: companies pricing both sides (20 points), share agreeing +EV (20), size of the edge (25, falling above 12%), a sharp book agreeing (25), tightness of the books' fair chances (10); ceilings by company count and a sharp book against. `starsBasis` = recorded (rated live) or estimated (worked out afterwards from the record, notably every bid and every bet before v0.89.17).
- **books / booksAgree**: companies (sister sites once) pricing BOTH sides behind the fair, and how many of those said +EV on their own. `sharp`: agree / against / none (no sharp book priced it); absent = not recorded.
- **how**: auto (auto-bet or auto-bid) / manual / lock. **made**: bet (taker) / bid (maker fill). **leadMin**: minutes before the start when placed. **liquidity**: dollars Novig had at the price. **result**: won / lost / push / void / fmv / open; **profit** in dollars, **roi** = profit/stake.
- `outlier: true` = an EV beyond +-6% that the app leaves out of its averages (so do the tables here); `lockFor` = a bet that locks in another's profit (not a pick).
- A field absent from a line is unknown for that bet (never 0 or empty). Times are America/New_York.

## Headline
**Read the INDEPENDENT-close CLV first**: a close read from the market before the start is, for a CrazyNinjaOdds bet, the same consensus that found it (partly circular); the independent figure (a sharp book's or ESPN's price at the start) cannot be.
- All · 1535 bets (77 open) · 670-779-8 (win 46%) · ROI -2.9% · profit -57.39 · EV when placed +3.3% · CLV +1.3% on 1244 closed (beat close 68%, t=6.4) · INDEPENDENT-close CLV +2.1% on 489 (beat 76%) · expected +63.11 vs actual -73.78
- Bets (taker orders) · 1162 bets (68 open) · 497-591-5 (win 46%) · ROI -4.5% · profit -64.80 · EV when placed +3.2% · CLV +1.0% on 953 closed (beat close 67%, t=4.3) · INDEPENDENT-close CLV +2.0% on 377 (beat 74%) · expected +45.50 vs actual -78.79
- Bid fills · 373 bets (9 open) · 173-188-3 (win 48%) · ROI +1.5% · profit +7.40 · EV when placed +3.6% · CLV +2.0% on 291 closed (beat close 72%, t=6.6) · INDEPENDENT-close CLV +2.8% on 112 (beat 83%) · expected +17.61 vs actual +5.01

## Splits (every dimension on its own)
### Bet or bid
- Bets (taker orders) · 1162 bets (68 open) · 497-591-5 (win 46%) · ROI -4.5% · profit -64.80 · EV when placed +3.2% · CLV +1.0% on 953 closed (beat close 67%, t=4.3) · INDEPENDENT-close CLV +2.0% on 377 (beat 74%) · expected +45.50 vs actual -78.79
- Bids (make orders that filled) · 373 bets (9 open) · 173-188-3 (win 48%) · ROI +1.5% · profit +7.40 · EV when placed +3.6% · CLV +2.0% on 291 closed (beat close 72%, t=6.6) · INDEPENDENT-close CLV +2.8% on 112 (beat 83%) · expected +17.61 vs actual +5.01

### Auto or manual
- Manual · 754 bets (18 open) · 335-394-7 (win 46%) · ROI -6.2% · profit -55.53 · EV when placed +3.1% · CLV +0.6% on 616 closed (beat close 62%, t=1.9) · INDEPENDENT-close CLV +2.0% on 223 (beat 72%) · expected +25.75 vs actual -60.89
- Auto · 781 bets (59 open) · 335-385-1 (win 47%) · ROI -1.4% · profit -14.18 · EV when placed +3.4% · CLV +1.9% on 628 closed (beat close 74%, t=8.5) · INDEPENDENT-close CLV +2.3% on 266 (beat 79%) · expected +37.36 vs actual -12.89
- Lock (profit locked in) · 0 bets (0 open) · ROI +79.3% · profit +12.31 · EV when placed n/a · CLV n/a (no true close yet)

### Type of bet
- Player props · 989 bets (3 open) · 430-551-4 (win 44%) · ROI -8.8% · profit -122.24 · EV when placed +3.4% · CLV +1.5% on 873 closed (beat close 72%, t=7.3) · INDEPENDENT-close CLV +2.1% on 375 (beat 79%) · expected +46.83 vs actual -136.56
- Game totals · 166 bets (26 open) · 74-66 (win 53%) · ROI +11.7% · profit +17.24 · EV when placed +2.9% · CLV +0.3% on 106 closed (beat close 51%, t=0.3) · INDEPENDENT-close CLV +2.0% on 32 (beat 59%) · expected +4.23 vs actual +16.92
- Spreads · 162 bets (32 open) · 67-62-1 (win 52%) · ROI +14.8% · profit +22.68 · EV when placed +2.8% · CLV -1.0% on 109 closed (beat close 54%, t=-1.1) · INDEPENDENT-close CLV +1.3% on 33 (beat 58%) · expected +4.35 vs actual +20.35
- Team totals · 108 bets (1 open) · 58-49 (win 54%) · ROI +19.4% · profit +29.27 · EV when placed +3.6% · CLV +2.6% on 101 closed (beat close 75%, t=5.9) · INDEPENDENT-close CLV +2.8% on 32 (beat 81%) · expected +5.56 vs actual +28.23
- Moneylines · 59 bets (13 open) · 18-28 (win 39%) · ROI -24.3% · profit -10.46 · EV when placed +3.1% · CLV -2.1% on 13 closed (beat close 38%, t=-0.5) · INDEPENDENT-close CLV +1.9% on 10 (beat 50%) · expected +1.37 vs actual -10.46
- Other · 27 bets (2 open) · 10-12-3 (win 45%) · ROI -1.4% · profit -0.51 · EV when placed +2.3% · CLV +1.2% on 19 closed (beat close 58%, t=0.5) · no independent close · expected +0.02 vs actual +0.75
- 1st half / inning / set lines · 24 bets (0 open) · 13-11 (win 54%) · ROI +24.9% · profit +6.62 · EV when placed +2.9% · CLV +2.8% on 23 closed (beat close 70%, t=2.4) · INDEPENDENT-close CLV +5.0% on 7 (beat 100%) · expected +0.75 vs actual +6.99

### Sport
- Football · 647 bets (11 open) · 277-356-3 (win 44%) · ROI -9.8% · profit -84.56 · EV when placed +3.2% · CLV +1.3% on 599 closed (beat close 70%, t=4.2) · INDEPENDENT-close CLV +2.1% on 253 (beat 77%) · expected +28.35 vs actual -89.67
- Hockey · 241 bets (7 open) · 113-120 (win 48%) · ROI -0.7% · profit -2.46 · EV when placed +3.6% · CLV +2.2% on 214 closed (beat close 75%, t=6.3) · INDEPENDENT-close CLV +2.3% on 118 (beat 78%) · expected +13.60 vs actual -3.13
- College football · 199 bets (30 open) · 91-78 (win 54%) · ROI +23.3% · profit +46.35 · EV when placed +3.0% · CLV +0.4% on 156 closed (beat close 62%, t=0.7) · INDEPENDENT-close CLV +2.9% on 35 (beat 77%) · expected +6.22 vs actual +45.24
- Basketball · 151 bets (3 open) · 65-83 (win 44%) · ROI -6.4% · profit -12.00 · EV when placed +3.2% · CLV +0.6% on 123 closed (beat close 63%, t=0.9) · INDEPENDENT-close CLV +0.8% on 43 (beat 65%) · expected +6.28 vs actual -14.39
- Baseball · 140 bets (0 open) · 65-71-4 (win 48%) · ROI +1.3% · profit +2.56 · EV when placed +3.5% · CLV +1.3% on 120 closed (beat close 67%, t=2.7) · INDEPENDENT-close CLV +2.6% on 34 (beat 79%) · expected +6.59 vs actual -2.70
- Tennis · 85 bets (26 open) · 21-37-1 (win 36%) · ROI -23.2% · profit -13.39 · EV when placed +3.6% · CLV +2.2% on 23 closed (beat close 61%, t=1.3) · INDEPENDENT-close CLV +5.7% on 6 (beat 33%) · expected +2.02 vs actual -11.21
- Other · 70 bets (0 open) · 36-34 (win 51%) · ROI +5.4% · profit +4.01 · EV when placed n/a · CLV -2.9% on 7 closed (beat close 0%, t=-3.8) · no independent close
- Soccer · 2 bets (0 open) · 2-0 (win 100%) · ROI +105.0% · profit +2.09 · EV when placed +2.3% · CLV +0.9% on 2 closed (beat close 50%) · no independent close · expected +0.05 vs actual +2.09

### Star rating
- 5★ · 16 bets (4 open) · 1-10-1 (win 9%) · ROI -74.2% · profit -13.66 · EV when placed +4.8% · CLV +3.9% on 10 closed (beat close 80%, t=3.5) · INDEPENDENT-close CLV +3.3% on 6 (beat 83%) · expected +0.77 vs actual -13.89
- 4½★ · 186 bets (23 open) · 64-99 (win 39%) · ROI -14.6% · profit -37.61 · EV when placed +3.7% · CLV +2.1% on 160 closed (beat close 80%, t=4.0) · INDEPENDENT-close CLV +3.4% on 80 (beat 86%) · expected +9.96 vs actual -37.61
- 4★ · 350 bets (29 open) · 163-156-1 (win 51%) · ROI +6.5% · profit +30.50 · EV when placed +3.2% · CLV +1.7% on 309 closed (beat close 73%, t=4.7) · INDEPENDENT-close CLV +1.6% on 138 (beat 73%) · expected +15.82 vs actual +30.42
- 3½★ · 257 bets (7 open) · 118-132 (win 47%) · ROI -0.8% · profit -2.78 · EV when placed +3.5% · CLV +1.6% on 230 closed (beat close 70%, t=4.7) · INDEPENDENT-close CLV +1.8% on 96 (beat 78%) · expected +12.95 vs actual -2.78
- 3★ · 108 bets (5 open) · 44-59 (win 43%) · ROI -9.8% · profit -14.76 · EV when placed +3.6% · CLV +1.8% on 97 closed (beat close 67%, t=2.5) · INDEPENDENT-close CLV +4.1% on 28 (beat 82%) · expected +5.89 vs actual -14.76
- 2½★ · 37 bets (0 open) · 15-22 (win 41%) · ROI -17.7% · profit -9.38 · EV when placed +3.2% · CLV +1.6% on 36 closed (beat close 75%, t=2.5) · INDEPENDENT-close CLV +1.9% on 18 (beat 78%) · expected +1.72 vs actual -9.38
- 2★ · 1 bets (0 open) · 1-0 (win 100%) · ROI +117.4% · profit +1.32 · EV when placed +2.9% · CLV -5.4% on 1 closed (beat close 0%) · no independent close · expected +0.03 vs actual +1.32
- 1½★ · 85 bets (6 open) · 39-39-1 (win 50%) · ROI -9.5% · profit -7.23 · EV when placed +3.5% · CLV +1.4% on 12 closed (beat close 75%, t=1.4) · no independent close · expected +2.64 vs actual -5.94
- Not rated · 495 bets (3 open) · 225-262-5 (win 46%) · ROI -0.7% · profit -3.80 · EV when placed +2.9% · CLV +0.2% on 389 closed (beat close 57%, t=0.4) · INDEPENDENT-close CLV +1.8% on 123 (beat 68%) · expected +13.33 vs actual -21.17

### Sharp book
- A sharp book agreed · 795 bets (67 open) · 335-389-3 (win 46%) · ROI -3.4% · profit -36.48 · EV when placed +3.4% · CLV +1.9% on 690 closed (beat close 75%, t=8.2) · INDEPENDENT-close CLV +2.4% on 312 (beat 80%) · expected +37.57 vs actual -35.50
- Not recorded · 634 bets (3 open) · 289-337-5 (win 46%) · ROI -2.5% · profit -18.44 · EV when placed +3.2% · CLV +0.4% on 462 closed (beat close 58%, t=0.9) · INDEPENDENT-close CLV +1.8% on 146 (beat 71%) · expected +20.78 vs actual -35.80
- No sharp book priced it · 90 bets (7 open) · 43-40 (win 52%) · ROI +12.6% · profit +13.59 · EV when placed +3.5% · CLV +1.4% on 76 closed (beat close 70%, t=1.7) · INDEPENDENT-close CLV +1.4% on 23 (beat 57%) · expected +3.97 vs actual +13.59
- A sharp book said no · 16 bets (0 open) · 3-13 (win 19%) · ROI -65.5% · profit -16.07 · EV when placed +3.1% · CLV +0.6% on 16 closed (beat close 63%, t=0.6) · INDEPENDENT-close CLV +1.1% on 8 (beat 63%) · expected +0.79 vs actual -16.07

### Books behind the fair
- 1 book · 81 bets (6 open) · 35-39-1 (win 47%) · ROI -10.4% · profit -7.48 · EV when placed +3.5% · CLV +1.4% on 12 closed (beat close 75%, t=1.4) · no independent close · expected +2.50 vs actual -6.19
- 2 books · 21 bets (1 open) · 7-13 (win 35%) · ROI -6.3% · profit -2.04 · EV when placed +3.9% · CLV +3.7% on 18 closed (beat close 72%, t=1.8) · INDEPENDENT-close CLV +11.0% on 4 (beat 75%) · expected +1.27 vs actual -2.04
- 3 books · 140 bets (6 open) · 58-76 (win 43%) · ROI -9.9% · profit -22.01 · EV when placed +3.8% · CLV +2.7% on 123 closed (beat close 76%, t=5.2) · INDEPENDENT-close CLV +2.3% on 35 (beat 71%) · expected +8.80 vs actual -22.01
- 4-5 books · 325 bets (12 open) · 145-166-1 (win 47%) · ROI -3.0% · profit -14.52 · EV when placed +3.5% · CLV +1.4% on 301 closed (beat close 71%, t=4.0) · INDEPENDENT-close CLV +1.7% on 97 (beat 74%) · expected +17.32 vs actual -14.61
- 6-9 books · 327 bets (29 open) · 142-155-1 (win 48%) · ROI -1.3% · profit -5.60 · EV when placed +3.4% · CLV +1.6% on 284 closed (beat close 73%, t=4.5) · INDEPENDENT-close CLV +2.3% on 158 (beat 80%) · expected +15.00 vs actual -5.83
- 10 or more books · 142 bets (20 open) · 54-68 (win 44%) · ROI -1.5% · profit -2.18 · EV when placed +3.0% · CLV +1.7% on 117 closed (beat close 76%, t=3.8) · INDEPENDENT-close CLV +2.6% on 72 (beat 85%) · expected +4.76 vs actual -2.18
- Not recorded · 499 bets (3 open) · 229-262-5 (win 47%) · ROI -0.6% · profit -3.56 · EV when placed +2.9% · CLV +0.2% on 389 closed (beat close 57%, t=0.4) · INDEPENDENT-close CLV +1.8% on 123 (beat 68%) · expected +13.47 vs actual -20.92

### Books agreeing
- Every book agreed · 546 bets (59 open) · 221-263-2 (win 46%) · ROI -4.2% · profit -29.63 · EV when placed +3.3% · CLV +1.8% on 470 closed (beat close 76%, t=6.1) · INDEPENDENT-close CLV +2.5% on 205 (beat 79%) · expected +25.05 vs actual -29.94
- All but one agreed · 47 bets (5 open) · 15-27 (win 36%) · ROI -21.0% · profit -10.63 · EV when placed +2.9% · CLV -0.1% on 37 closed (beat close 59%, t=-0.1) · INDEPENDENT-close CLV -0.3% on 23 (beat 52%) · expected +1.56 vs actual -10.63
- Half or more agreed · 12 bets (2 open) · 6-4 (win 60%) · ROI +11.1% · profit +1.61 · EV when placed +2.9% · CLV +0.5% on 9 closed (beat close 78%, t=0.2) · INDEPENDENT-close CLV -0.6% on 7 (beat 71%) · expected +0.44 vs actual +1.61
- Not recorded · 930 bets (11 open) · 428-485-6 (win 47%) · ROI -1.6% · profit -18.75 · EV when placed +3.3% · CLV +1.0% on 728 closed (beat close 63%, t=3.6) · INDEPENDENT-close CLV +2.2% on 254 (beat 76%) · expected +36.07 vs actual -34.82

### EV when placed
- Under 1% · 9 bets (1 open) · 4-4 (win 50%) · ROI +45.9% · profit +11.56 · EV when placed +0.4% · CLV -1.1% on 8 closed (beat close 38%, t=-0.8) · INDEPENDENT-close CLV +1.0% on 3 (beat 67%) · expected +0.04 vs actual -0.75
- 1–2% · 146 bets (15 open) · 61-69 (win 47%) · ROI +0.9% · profit +1.14 · EV when placed +1.6% · CLV +0.0% on 122 closed (beat close 56%, t=0.1) · INDEPENDENT-close CLV +2.4% on 46 (beat 67%) · expected +2.06 vs actual +1.14
- 2–3% · 409 bets (23 open) · 183-201-2 (win 48%) · ROI -1.9% · profit -8.36 · EV when placed +2.5% · CLV +0.4% on 355 closed (beat close 66%, t=1.2) · INDEPENDENT-close CLV +1.3% on 157 (beat 77%) · expected +11.37 vs actual -8.47
- 3–4% · 512 bets (23 open) · 229-258-2 (win 47%) · ROI -0.5% · profit -3.33 · EV when placed +3.5% · CLV +1.9% on 438 closed (beat close 73%, t=6.6) · INDEPENDENT-close CLV +2.5% on 179 (beat 78%) · expected +24.39 vs actual -2.00
- 4–6% · 361 bets (12 open) · 147-201-1 (win 42%) · ROI -11.7% · profit -63.46 · EV when placed +4.7% · CLV +2.0% on 293 closed (beat close 70%, t=4.8) · INDEPENDENT-close CLV +2.7% on 104 (beat 75%) · expected +25.26 vs actual -63.69
- 6% and up · 0 bets (0 open) · ROI n/a · profit +0.00 · EV when placed n/a · CLV n/a (no true close yet)
- No EV on record · 98 bets (3 open) · 46-46-3 (win 50%) · ROI +4.7% · profit +5.07 · EV when placed n/a · CLV +0.9% on 28 closed (beat close 54%, t=0.5) · no independent close

### Time before the game
- under 30 min · 125 bets (2 open) · 55-65-3 (win 46%) · ROI -0.5% · profit -0.84 · EV when placed +3.1% · CLV +3.5% on 121 closed (beat close 88%, t=13.0) · INDEPENDENT-close CLV +3.9% on 47 (beat 91%) · expected +5.07 vs actual -1.83
- 30 min-2 h · 148 bets (0 open) · 68-80 (win 46%) · ROI -7.1% · profit -15.54 · EV when placed +3.6% · CLV +2.8% on 138 closed (beat close 88%, t=10.6) · INDEPENDENT-close CLV +2.9% on 54 (beat 91%) · expected +7.81 vs actual -17.41
- 2-6 h · 297 bets (8 open) · 129-157-2 (win 45%) · ROI -4.8% · profit -19.46 · EV when placed +3.3% · CLV +2.4% on 276 closed (beat close 76%, t=8.7) · INDEPENDENT-close CLV +2.9% on 103 (beat 80%) · expected +13.46 vs actual -17.23
- 6-24 h · 523 bets (22 open) · 240-261 (win 48%) · ROI +0.8% · profit +5.50 · EV when placed +3.4% · CLV +0.5% on 407 closed (beat close 60%, t=1.4) · INDEPENDENT-close CLV +1.4% on 163 (beat 72%) · expected +22.03 vs actual -2.00
- 24 h or more · 380 bets (45 open) · 148-184-3 (win 45%) · ROI -5.1% · profit -21.36 · EV when placed +3.0% · CLV -0.3% on 302 closed (beat close 55%, t=-0.5) · INDEPENDENT-close CLV +1.4% on 122 (beat 65%) · expected +12.90 vs actual -30.51
- after the start · 62 bets (0 open) · 30-32 (win 48%) · ROI -11.2% · profit -5.69 · EV when placed +3.6% · CLV n/a (no true close yet) · expected +1.84 vs actual -4.80

### Liquidity
- Under $10 · 149 bets (17 open) · 63-67-1 (win 48%) · ROI +6.8% · profit +11.73 · EV when placed +3.6% · CLV +2.1% on 123 closed (beat close 76%, t=3.1) · INDEPENDENT-close CLV +2.1% on 43 (beat 79%) · expected +6.13 vs actual +11.50
- $10-25 · 71 bets (4 open) · 30-37 (win 45%) · ROI -11.0% · profit -10.46 · EV when placed +3.3% · CLV +2.1% on 65 closed (beat close 75%, t=3.2) · INDEPENDENT-close CLV +2.5% on 20 (beat 70%) · expected +3.49 vs actual -10.46
- $25-100 · 153 bets (10 open) · 66-77 (win 46%) · ROI -3.1% · profit -6.80 · EV when placed +3.2% · CLV +2.1% on 142 closed (beat close 80%, t=4.5) · INDEPENDENT-close CLV +1.9% on 76 (beat 79%) · expected +7.48 vs actual -6.80
- $100-500 · 196 bets (18 open) · 76-101-1 (win 43%) · ROI -12.8% · profit -36.57 · EV when placed +3.4% · CLV +1.2% on 166 closed (beat close 72%, t=2.5) · INDEPENDENT-close CLV +2.1% on 81 (beat 77%) · expected +10.12 vs actual -36.65
- $500 or more · 117 bets (17 open) · 43-57 (win 43%) · ROI -4.1% · profit -5.75 · EV when placed +3.5% · CLV +0.8% on 93 closed (beat close 63%, t=1.0) · INDEPENDENT-close CLV +2.5% on 38 (beat 74%) · expected +5.49 vs actual -5.75
- Not recorded · 849 bets (11 open) · 392-440-6 (win 47%) · ROI -0.9% · profit -9.54 · EV when placed +3.2% · CLV +0.9% on 655 closed (beat close 63%, t=3.2) · INDEPENDENT-close CLV +2.2% on 231 (beat 75%) · expected +30.40 vs actual -25.61

### Odds
- Underdog (+110 to +200) · 846 bets (47 open) · 333-464-2 (win 42%) · ROI -8.6% · profit -87.24 · EV when placed +3.5% · CLV +1.5% on 692 closed (beat close 67%, t=5.1) · INDEPENDENT-close CLV +2.5% on 264 (beat 76%) · expected +35.15 vs actual -78.76
- Even money (−110 to +110) · 513 bets (27 open) · 242-242-1 (win 50%) · ROI +0.7% · profit +4.47 · EV when placed +3.1% · CLV +1.0% on 428 closed (beat close 70%, t=3.3) · INDEPENDENT-close CLV +1.5% on 175 (beat 75%) · expected +20.43 vs actual -12.16
- Favorite (−200 to −110) · 158 bets (2 open) · 87-64-5 (win 58%) · ROI +12.3% · profit +30.25 · EV when placed +3.1% · CLV +1.2% on 120 closed (beat close 70%, t=2.2) · INDEPENDENT-close CLV +2.4% on 50 (beat 78%) · expected +6.94 vs actual +22.36
- Heavy favorite (−200 or shorter) · 9 bets (0 open) · 6-3 (win 67%) · ROI -19.5% · profit -2.71 · EV when placed +3.0% · CLV -5.0% on 2 closed (beat close 0%) · no independent close · expected +0.37 vs actual -3.06
- Long shot (over +200) · 9 bets (1 open) · 2-6 (win 25%) · ROI -44.5% · profit -2.16 · EV when placed +4.4% · CLV -0.1% on 2 closed (beat close 50%) · no independent close · expected +0.22 vs actual -2.16

### Scanner
- CNO · 876 bets (41 open) · 383-448-3 (win 46%) · ROI -2.8% · profit -30.81 · EV when placed +3.1% · CLV +1.1% on 740 closed (beat close 68%, t=3.8) · INDEPENDENT-close CLV +2.0% on 308 (beat 74%) · expected +34.29 vs actual -46.32
- Vigilant · 599 bets (36 open) · 257-301-5 (win 46%) · ROI -3.0% · profit -23.67 · EV when placed +3.6% · CLV +1.6% on 503 closed (beat close 68%, t=6.2) · INDEPENDENT-close CLV +2.4% on 181 (beat 78%) · expected +26.92 vs actual -24.55
- Live bids · 47 bets (0 open) · 21-26 (win 45%) · ROI -11.8% · profit -4.33 · EV when placed +3.6% · CLV n/a (no true close yet) · expected +1.35 vs actual -4.33
- Pinnodds live · 7 bets (0 open) · 3-4 (win 43%) · ROI -19.1% · profit -1.34 · EV when placed +4.3% · CLV n/a (no true close yet) · expected +0.30 vs actual -1.34
- Live tail · 4 bets (0 open) · 4-0 (win 100%) · ROI +6.3% · profit +0.25 · EV when placed +3.5% · CLV n/a (no true close yet) · expected +0.14 vs actual +0.25
- ParlayAPI · 2 bets (0 open) · 2-0 (win 100%) · ROI +125.9% · profit +2.51 · EV when placed +5.9% · CLV -10.1% on 1 closed (beat close 0%) · no independent close · expected +0.12 vs actual +2.51

### Close basis
- history:pinnacle · 473 bets (7 open) · 212-253-1 (win 46%) · ROI -4.9% · profit -32.17 · EV when placed +3.3% · CLV +2.1% on 473 closed (beat close 76%, t=7.6) · INDEPENDENT-close CLV +2.1% on 473 (beat 76%) · expected +22.12 vs actual -32.20
- No true close yet · 291 bets (67 open) · 99-120-4 (win 45%) · ROI -8.6% · profit -22.52 · EV when placed +3.4% · CLV n/a (no true close yet) · expected +6.36 vs actual -28.19
- history:novig-trades · 283 bets (0 open) · 131-150-2 (win 47%) · ROI +3.1% · profit +11.55 · EV when placed +3.1% · CLV -0.3% on 283 closed (beat close 49%, t=-0.6) · no independent close · expected +11.84 vs actual -5.73
- read:cno · 234 bets (0 open) · 109-124-1 (win 47%) · ROI -3.0% · profit -10.21 · EV when placed +3.3% · CLV +0.8% on 234 closed (beat close 71%, t=1.4) · no independent close · expected +11.85 vs actual -10.30
- read:vigilant · 198 bets (3 open) · 89-106 (win 46%) · ROI -3.6% · profit -9.11 · EV when placed +3.5% · CLV +1.6% on 198 closed (beat close 69%, t=4.6) · no independent close · expected +8.61 vs actual -2.44
- read:both · 40 bets (0 open) · 20-20 (win 50%) · ROI -0.1% · profit -0.05 · EV when placed +3.4% · CLV +2.6% on 40 closed (beat close 83%, t=3.9) · no independent close · expected +1.89 vs actual -0.05
- history:espn · 16 bets (0 open) · 10-6 (win 63%) · ROI +28.3% · profit +5.12 · EV when placed +2.4% · CLV +3.4% on 16 closed (beat close 81%, t=3.9) · INDEPENDENT-close CLV +3.4% on 16 (beat 81%) · expected +0.45 vs actual +5.12

### By week placed
- week of 2026-09-21 · 130 bets (0 open) · 69-61 (win 53%) · ROI +9.8% · profit +12.83 · EV when placed +2.7% · CLV +1.2% on 64 closed (beat close 59%, t=1.6) · INDEPENDENT-close CLV +3.7% on 20 (beat 85%) · expected +1.82 vs actual +6.51
- week of 2026-09-28 · 475 bets (0 open) · 213-259-3 (win 45%) · ROI -2.6% · profit -16.26 · EV when placed +3.1% · CLV +0.3% on 440 closed (beat close 61%, t=0.8) · INDEPENDENT-close CLV +1.6% on 166 (beat 70%) · expected +19.56 vs actual -30.26
- week of 2026-10-05 · 729 bets (3 open) · 330-392-3 (win 46%) · ROI -4.5% · profit -47.64 · EV when placed +3.5% · CLV +1.9% on 663 closed (beat close 74%, t=10.0) · INDEPENDENT-close CLV +2.5% on 261 (beat 82%) · expected +36.88 vs actual -46.83
- week of 2026-10-12 · 201 bets (74 open) · 58-67-2 (win 46%) · ROI -4.8% · profit -6.32 · EV when placed +3.4% · CLV +0.8% on 77 closed (beat close 61%, t=0.8) · INDEPENDENT-close CLV +1.5% on 42 (beat 52%) · expected +4.85 vs actual -3.20

## Automatic findings (closing-line value, strongest evidence first)
### Beating the close
- Time before the game = under 30 min: CLV +3.5% on 121 closed (t=13.0, beat close 88%) · ROI -0.6% · profit -0.98
- Sharp book = A sharp book agreed AND Time before the game = under 30 min: CLV +3.8% on 84 closed (t=12.9, beat close 92%) · ROI -8.0% · profit -9.51
- Type of bet = Player props AND Time before the game = under 30 min: CLV +3.8% on 91 closed (t=12.6, beat close 93%) · ROI -2.7% · profit -3.32
- Bet or bid = Bets (taker orders) AND Time before the game = under 30 min: CLV +3.7% on 100 closed (t=12.1, beat close 89%) · ROI -0.3% · profit -0.44
- Auto or manual = Auto AND Time before the game = under 30 min: CLV +3.4% on 67 closed (t=12.0, beat close 90%) · ROI +0.6% · profit +0.58
- Sport = Football AND Time before the game = under 30 min: CLV +3.5% on 72 closed (t=11.6, beat close 93%) · ROI -8.0% · profit -7.26
- Time before the game = under 30 min AND Scanner = CNO: CLV +3.9% on 72 closed (t=11.4, beat close 90%) · ROI +0.9% · profit +0.95
- Type of bet = Player props AND Time before the game = 30 min-2 h: CLV +3.0% on 109 closed (t=11.3, beat close 91%) · ROI -8.6% · profit -14.07
- Time before the game = 30 min-2 h: CLV +2.8% on 138 closed (t=10.6, beat close 88%) · ROI -4.8% · profit -9.81
- Time before the game = under 30 min AND Odds = Underdog (+110 to +200): CLV +4.3% on 66 closed (t=10.5, beat close 86%) · ROI -12.1% · profit -9.58
- EV when placed = 3–4% AND Time before the game = under 30 min: CLV +4.5% on 34 closed (t=10.1, beat close 97%) · ROI -13.0% · profit -6.26
- Star rating = 4½★ AND Time before the game = 2-6 h: CLV +3.9% on 41 closed (t=9.6, beat close 93%) · ROI -32.3% · profit -20.30
- Time before the game = under 30 min AND Odds = Even money (−110 to +110): CLV +2.5% on 47 closed (t=9.5, beat close 91%) · ROI -1.4% · profit -0.95
- EV when placed = 4–6% AND Time before the game = under 30 min: CLV +5.0% on 26 closed (t=9.5, beat close 96%) · ROI +24.8% · profit +10.35
- Books behind the fair = 6-9 books AND Time before the game = 30 min-2 h: CLV +3.1% on 56 closed (t=9.1, beat close 89%) · ROI +4.5% · profit +3.75
### Giving the close away
- Type of bet = Spreads AND Odds = Even money (−110 to +110): CLV -4.2% on 41 closed (t=-2.4, beat close 39%) · ROI +24.5% · profit +11.44
- Type of bet = Spreads AND EV when placed = 1–2%: CLV -3.4% on 30 closed (t=-1.8, beat close 37%) · ROI -23.1% · profit -6.75
- Time before the game = 24 h or more AND Odds = Even money (−110 to +110): CLV -1.5% on 89 closed (t=-1.5, beat close 46%) · ROI +2.5% · profit +2.69
- Type of bet = Game totals AND Odds = Even money (−110 to +110): CLV -1.9% on 35 closed (t=-1.5, beat close 40%) · ROI +13.8% · profit +5.35
- EV when placed = 1–2% AND Odds = Even money (−110 to +110): CLV -1.4% on 67 closed (t=-1.4, beat close 57%) · ROI -1.1% · profit -0.76
- Time before the game = 6-24 h AND Liquidity = $500 or more: CLV -2.5% on 29 closed (t=-1.3, beat close 52%) · ROI -31.0% · profit -11.42
- Bet or bid = Bets (taker orders) AND Type of bet = Spreads: CLV -1.2% on 105 closed (t=-1.2, beat close 52%) · ROI +20.9% · profit +25.22
- EV when placed = 1–2% AND Time before the game = 6-24 h: CLV -1.6% on 35 closed (t=-1.2, beat close 43%) · ROI -12.4% · profit -4.33
- Type of bet = Spreads AND EV when placed = 2–3%: CLV -2.0% on 40 closed (t=-1.1, beat close 60%) · ROI +17.7% · profit +7.07
- Sport = Basketball AND Sharp book = A sharp book agreed: CLV -1.4% on 54 closed (t=-1.1, beat close 59%) · ROI +4.4% · profit +3.41
- EV when placed = 2–3% AND Time before the game = 24 h or more: CLV -1.1% on 98 closed (t=-1.1, beat close 54%) · ROI -3.3% · profit -3.53
- EV when placed = 2–3% AND Time before the game = 6-24 h: CLV -0.9% on 89 closed (t=-1.1, beat close 54%) · ROI +12.1% · profit +13.34
- Sport = College football AND Odds = Even money (−110 to +110): CLV -1.4% on 52 closed (t=-1.1, beat close 56%) · ROI +34.2% · profit +20.49
- Type of bet = Spreads: CLV -1.0% on 109 closed (t=-1.1, beat close 54%) · ROI +20.4% · profit +25.88
- Auto or manual = Manual AND Type of bet = Spreads: CLV -1.2% on 77 closed (t=-1.0, beat close 51%) · ROI +21.6% · profit +17.88
(t = mean CLV over its standard error: |t| of 2+ is hard to get by luck for one group, but this scans 1446 groups, so expect some at |t| of 2-3 by chance alone: trust the ones that are large AND make sense, and that hold on `closeIndependent: true` bets.)

## Bids posted (all, filled or not)
- All bids · 22234 posted · 245 filled (1%), 218 fully · $383.22 paid · median time to first fill 94s · picked off (fair under price at the fill) 1% of 231 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- status canceled: 21205
- status expired: 794
- status filled: 218
- status refused: 16
- status lost: 1
### By kind
- Player props · 11924 posted · 174 filled (1%), 152 fully · $277.49 paid · median time to first fill 86s · picked off (fair under price at the fill) 1% of 167 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- Team totals · 8589 posted · 65 filled (1%), 61 fully · $99.22 paid · median time to first fill 133s · picked off (fair under price at the fill) 2% of 59 judged, mean fill EV +3.7% · mean EV at posting +3.8%
- 1st half / inning / set lines · 961 posted · 4 filled (0%), 4 fully · $4.87 paid · median time to first fill 106s · picked off (fair under price at the fill) 0% of 4 judged, mean fill EV +2.8% · mean EV at posting +3.1%
- Game totals · 416 posted · 1 filled (0%), 1 fully · $0.71 paid · mean EV at posting +3.3%
- Spreads · 278 posted · 0 filled (0%), 0 fully · $0.00 paid · mean EV at posting +3.0%
- Moneylines · 66 posted · 1 filled (2%), 0 fully · $0.93 paid · median time to first fill 2s · picked off (fair under price at the fill) 0% of 1 judged, mean fill EV +1.0% · mean EV at posting +2.6%
### By time before the start when posted
- under 30 min · 608 posted · 14 filled (2%), 12 fully · $14.88 paid · median time to first fill 93s · picked off (fair under price at the fill) 0% of 13 judged, mean fill EV +3.1% · mean EV at posting +3.5%
- 30 min-2 h · 1603 posted · 36 filled (2%), 32 fully · $57.10 paid · median time to first fill 91s · picked off (fair under price at the fill) 0% of 35 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- 2-6 h · 5682 posted · 81 filled (1%), 73 fully · $111.13 paid · median time to first fill 104s · picked off (fair under price at the fill) 3% of 77 judged, mean fill EV +3.3% · mean EV at posting +3.6%
- 6-24 h · 11513 posted · 112 filled (1%), 99 fully · $197.04 paid · median time to first fill 93s · picked off (fair under price at the fill) 0% of 104 judged, mean fill EV +3.6% · mean EV at posting +3.6%
- 24 h or more · 2828 posted · 2 filled (0%), 2 fully · $3.07 paid · median time to first fill 9s · picked off (fair under price at the fill) 0% of 2 judged, mean fill EV +2.8% · mean EV at posting +3.8%
### By scanner / auto
- vigilant (auto) · 22018 posted · 236 filled (1%), 211 fully · $363.82 paid · median time to first fill 102s · picked off (fair under price at the fill) 1% of 222 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- cno (auto) · 216 posted · 9 filled (4%), 7 fully · $19.41 paid · median time to first fill 2s · picked off (fair under price at the fill) 0% of 9 judged, mean fill EV +3.7% · mean EV at posting +3.5%

## Data quality
- without the record as placed (older or imported bets): 519 of 1648 (31%)
- with a recorded star rating (rated live): 231 of 1648 (14%)
- with an estimated star rating: 898 of 1648 (54%)
- with no star rating possible: 519 of 1648 (31%)
- started but with no true close: 267 of 1648 (16%)
- left out of the averages as outliers: 102 of 1648 (6%)
- open: 81 of 1648 (5%)
- true closes by basis: history:pinnacle 484, history:novig-trades 300, read:cno 242, read:vigilant 215, read:both 42, history:espn 16

