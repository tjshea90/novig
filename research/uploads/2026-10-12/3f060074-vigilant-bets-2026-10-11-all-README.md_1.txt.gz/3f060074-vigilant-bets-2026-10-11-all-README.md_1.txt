# Vigilant bet history (everything)

Generated 2026-10-11T23:18:25.768-04:00 by Vigilant (format 1). **1422 bets and bid fills** (300 are bid fills), **25156 bids posted**, from 2026-09-25 to 2026-10-11.

## Your task
Tj bets on Novig (a US exchange) with a +EV scanner, **Vigilant**. The goal is PROFIT through positive EV that the CLOSING LINE confirms. From the files below find (1) which kinds of bets and bids beat the close and are
profitable and which do not, (2) whether the app's own star rating, sharp-book check and agreement counts predict beating the close, (3) specific filters, thresholds and rule changes for the auto-bet
and the auto-bid desk (name the setting or the code: Presets.kt, SharpVeto.kt, AutoBet.kt, MakerRules.kt, BetRating.kt), (4) data-quality problems in the logging itself. Judge groups by CLV first (it needs far fewer
bets than profit to say anything): a group wants roughly 100+ bets with a true close before CLV means much and 1,000+ before ROI does. State the sample size and t-statistic behind every claim, say when the sample is too small, and
do not recommend a change on a handful of bets. Bets and bids are different instruments (a bid can be picked off; a bet cannot): read them apart.

## Files
- `vigilant-bets-2026-10-11-all-bets-p1.jsonl`: bets and bid fills, one JSON object per line, oldest first
- `vigilant-bets-2026-10-11-all-bids-posted-p1.jsonl`: every bid posted (filled or not), one JSON object per line
- this README: dictionary, definitions, summary tables and automatic findings

## Definitions
- **Odds** are American. `cost` is the price paid per $1 of payout including Novig's taker fee (a pregame taker fee is 0; a bid pays no fee). EV, CLV, ROI, fair and win % are fractions (0.03 = +3%).
- **EV** (`ev`): `fair / cost - 1` at the moment of placing, against the fair chance the app had then (devigged books). For a bid it is the edge at its fair when it was POSTED.
- **Fair** (`fair`, `fairOdds`): the no-vig chance of the bet's side from the books (worst-case devig, lower of mean and median; sister sites count once; books with wrong-looking odds are left out).
- **Close and CLV**: `closeFair` is the same side's no-vig chance at the START of the game; `closeOdds` is that as American odds (a fair price, not a book price: do not compare it with `odds` without the vig in mind - `clv` already does). `clv = closeFair / cost - 1`:
  positive = the bet was cheaper than the market's final opinion. It exists ONLY for a TRUE close: a read of the market in the last 15 minutes before the start made at least 60 s after the bet (a read seconds after the bet is its own line, not a close), or a history source's price at the start. `closeSource` = captured or the history source.
  `closeBasis` says what the close is made of: `read:cno` (CrazyNinjaOdds' consensus, the SAME kind of consensus that found most CNO bets), `read:vigilant` (Vigilant's own fair line), `read:both`, `history:pinnacle` (Pinnacle's price at the start, via ParlayAPI/SGO/OddsPapi), `history:espn`, `history:novig-trades` (the last 3+ trades on Novig in the last 15 minutes, the bettor's own fills included).
  `closeIndependent` = true only for history from another source than the one that found the bet (a sharp book's price at the start, or ESPN's): CLV against `read:cno` is partly circular (the bet and its close come from one consensus), so **test every CLV claim on `closeIndependent: true` bets too**. When both exist the sharp book's price at the start is the close (the app asks for it even when a read before the start exists); `startsLoggedMs`/`startsNote` appear when a game started early or late and the start was corrected. For a read, `closeReadMs`/`closeLeadSec` say when it was taken and how many seconds before the start, `closeReadAfterBetSec` how long after the bet; a history close has no read time (it is the price at the start).
  Closes found after the game are devigged by the same conservative WORST-CASE method as the app's own fair (the lowest fair chance of four methods; `AtBet`'s `fairMethod` says which method priced each bet: bets before v0.89.19 used POWER); before v0.89.18 history closes were multiplicative, which flatters longshots by 5-13% (so very old history closes on dogs are biased high). `novigCloseOdds`/`novigCloseAgeSec` = Novig's own last price when it was read in the last 15 minutes before the start.
- **Stars** (`stars`, 1-5 in halves): the app's rating of how much to TRUST the edge: companies pricing both sides (20 points), share agreeing +EV (20), size of the edge (25, falling above 12%), a sharp book agreeing (25), tightness of the books' fair chances (10); ceilings by company count and a sharp book against. `starsBasis` = recorded (rated live) or estimated (worked out afterwards from the record, notably every bid and every bet before v0.89.17).
- **books / booksAgree**: companies (sister sites once) pricing BOTH sides behind the fair, and how many of those said +EV on their own. `sharp`: agree / against / none (no sharp book priced it); absent = not recorded.
- **how**: auto (auto-bet or auto-bid) / manual / lock. **made**: bet (taker) / bid (maker fill). **leadMin**: minutes before the start when placed. **liquidity**: dollars Novig had at the price. **result**: won / lost / push / void / fmv / open; **profit** in dollars, **roi** = profit/stake.
- `outlier: true` = an EV beyond +-6% that the app leaves out of its averages (so do the tables here); `lockFor` = a bet that locks in another's profit (not a pick).
- A field absent from a line is unknown for that bet (never 0 or empty). Times are America/New_York.

## Headline
**Read the INDEPENDENT-close CLV first**: a close read from the market before the start is, for a CrazyNinjaOdds bet, the same consensus that found it (partly circular); the independent figure (a sharp book's or ESPN's price at the start) cannot be.
- All · 1331 bets (76 open) · 579-670-5 (win 46%) · ROI -2.1% · profit -36.90 · EV when placed +3.3% · CLV +1.3% on 1135 closed (beat close 69%, t=6.6) · INDEPENDENT-close CLV +2.2% on 434 (beat 78%) · expected +55.40 vs actual -58.33
- Bets (taker orders) · 1031 bets (44 open) · 451-532-3 (win 46%) · ROI -4.0% · profit -53.25 · EV when placed +3.2% · CLV +1.1% on 886 closed (beat close 67%, t=4.6) · INDEPENDENT-close CLV +2.1% on 336 (beat 76%) · expected +41.33 vs actual -69.83
- Bid fills · 300 bets (32 open) · 128-138-2 (win 48%) · ROI +4.0% · profit +16.34 · EV when placed +3.5% · CLV +2.0% on 249 closed (beat close 73%, t=6.6) · INDEPENDENT-close CLV +2.6% on 98 (beat 85%) · expected +14.07 vs actual +11.50

## Splits (every dimension on its own)
### Bet or bid
- Bets (taker orders) · 1031 bets (44 open) · 451-532-3 (win 46%) · ROI -4.0% · profit -53.25 · EV when placed +3.2% · CLV +1.1% on 886 closed (beat close 67%, t=4.6) · INDEPENDENT-close CLV +2.1% on 336 (beat 76%) · expected +41.33 vs actual -69.83
- Bids (make orders that filled) · 300 bets (32 open) · 128-138-2 (win 48%) · ROI +4.0% · profit +16.34 · EV when placed +3.5% · CLV +2.0% on 249 closed (beat close 73%, t=6.6) · INDEPENDENT-close CLV +2.6% on 98 (beat 85%) · expected +14.07 vs actual +11.50

### Auto or manual
- Manual · 693 bets (21 open) · 308-359-5 (win 46%) · ROI -5.7% · profit -47.22 · EV when placed +3.1% · CLV +0.5% on 569 closed (beat close 61%, t=1.5) · INDEPENDENT-close CLV +2.0% on 198 (beat 73%) · expected +23.37 vs actual -56.33
- Auto · 638 bets (55 open) · 271-311 (win 47%) · ROI -0.2% · profit -2.00 · EV when placed +3.5% · CLV +2.1% on 566 closed (beat close 76%, t=10.2) · INDEPENDENT-close CLV +2.4% on 236 (beat 81%) · expected +32.03 vs actual -2.00
- Lock (profit locked in) · 0 bets (0 open) · ROI +79.3% · profit +12.31 · EV when placed n/a · CLV n/a (no true close yet)

### Type of bet
- Player props · 931 bets (50 open) · 382-495-3 (win 44%) · ROI -8.8% · profit -111.43 · EV when placed +3.4% · CLV +1.5% on 811 closed (beat close 72%, t=7.1) · INDEPENDENT-close CLV +2.2% on 343 (beat 80%) · expected +42.32 vs actual -123.47
- Game totals · 123 bets (6 open) · 60-57 (win 51%) · ROI +9.7% · profit +12.35 · EV when placed +2.9% · CLV +0.3% on 97 closed (beat close 52%, t=0.3) · INDEPENDENT-close CLV +2.5% on 26 (beat 65%) · expected +3.51 vs actual +12.03
- Spreads · 111 bets (7 open) · 54-50 (win 52%) · ROI +17.6% · profit +21.90 · EV when placed +2.7% · CLV -0.7% on 92 closed (beat close 54%, t=-0.7) · INDEPENDENT-close CLV +2.4% on 23 (beat 61%) · expected +3.42 vs actual +18.28
- Team totals · 96 bets (3 open) · 52-41 (win 56%) · ROI +22.6% · profit +30.71 · EV when placed +3.6% · CLV +2.5% on 91 closed (beat close 74%, t=5.3) · INDEPENDENT-close CLV +2.9% on 29 (beat 83%) · expected +5.00 vs actual +29.67
- Moneylines · 26 bets (5 open) · 12-9 (win 57%) · ROI +2.2% · profit +0.44 · EV when placed +2.5% · CLV -2.0% on 8 closed (beat close 38%, t=-0.7) · INDEPENDENT-close CLV -2.1% on 7 (beat 43%) · expected +0.50 vs actual +0.44
- Other · 23 bets (3 open) · 10-8-2 (win 56%) · ROI +19.1% · profit +5.52 · EV when placed +2.3% · CLV +1.8% on 16 closed (beat close 63%, t=0.6) · no independent close · expected +0.02 vs actual +0.75
- 1st half / inning / set lines · 21 bets (2 open) · 9-10 (win 47%) · ROI +15.8% · profit +3.59 · EV when placed +3.0% · CLV +2.9% on 20 closed (beat close 65%, t=2.1) · INDEPENDENT-close CLV +5.3% on 6 (beat 100%) · expected +0.63 vs actual +3.96

### Sport
- Football · 617 bets (40 open) · 246-328-3 (win 43%) · ROI -10.5% · profit -83.82 · EV when placed +3.2% · CLV +1.2% on 567 closed (beat close 69%, t=3.9) · INDEPENDENT-close CLV +2.0% on 233 (beat 76%) · expected +26.09 vs actual -91.26
- Hockey · 195 bets (2 open) · 96-96 (win 50%) · ROI +3.3% · profit +10.94 · EV when placed +3.5% · CLV +2.5% on 185 closed (beat close 78%, t=6.9) · INDEPENDENT-close CLV +2.6% on 105 (beat 82%) · expected +11.83 vs actual +9.09
- College football · 170 bets (1 open) · 91-78 (win 54%) · ROI +23.3% · profit +46.35 · EV when placed +3.1% · CLV +0.4% on 156 closed (beat close 62%, t=0.7) · INDEPENDENT-close CLV +3.0% on 34 (beat 76%) · expected +6.22 vs actual +45.24
- Basketball · 130 bets (2 open) · 55-73 (win 43%) · ROI -8.5% · profit -13.78 · EV when placed +3.2% · CLV +1.6% on 111 closed (beat close 68%, t=3.1) · INDEPENDENT-close CLV +1.7% on 34 (beat 74%) · expected +5.47 vs actual -16.17
- Baseball · 122 bets (15 open) · 51-54-2 (win 49%) · ROI +0.7% · profit +1.08 · EV when placed +3.4% · CLV +1.1% on 105 closed (beat close 65%, t=2.3) · INDEPENDENT-close CLV +2.2% on 28 (beat 79%) · expected +5.39 vs actual -3.54
- Other · 70 bets (0 open) · 36-34 (win 51%) · ROI +5.4% · profit +4.01 · EV when placed n/a · CLV -2.3% on 6 closed (beat close 0%, t=-4.4) · no independent close
- Tennis · 25 bets (16 open) · 2-7 (win 22%) · ROI -36.0% · profit -3.77 · EV when placed +3.1% · CLV +0.5% on 3 closed (beat close 33%, t=0.3) · no independent close · expected +0.36 vs actual -3.77
- Soccer · 2 bets (0 open) · 2-0 (win 100%) · ROI +105.0% · profit +2.09 · EV when placed +2.3% · CLV +0.9% on 2 closed (beat close 50%) · no independent close · expected +0.05 vs actual +2.09

### Star rating
- 5★ · 8 bets (2 open) · 0-6 (win 0%) · ROI -100.0% · profit -6.38 · EV when placed +4.5% · CLV +5.2% on 7 closed (beat close 100%, t=6.4) · INDEPENDENT-close CLV +4.4% on 4 (beat 100%) · expected +0.28 vs actual -6.38
- 4½★ · 148 bets (12 open) · 53-83 (win 39%) · ROI -14.7% · profit -33.56 · EV when placed +3.8% · CLV +2.5% on 144 closed (beat close 82%, t=5.1) · INDEPENDENT-close CLV +3.7% on 71 (beat 89%) · expected +8.82 vs actual -33.56
- 4★ · 282 bets (20 open) · 135-125-1 (win 52%) · ROI +7.7% · profit +30.87 · EV when placed +3.3% · CLV +2.0% on 266 closed (beat close 75%, t=5.5) · INDEPENDENT-close CLV +2.0% on 115 (beat 77%) · expected +13.56 vs actual +30.78
- 3½★ · 229 bets (20 open) · 97-112 (win 46%) · ROI -0.4% · profit -1.36 · EV when placed +3.4% · CLV +1.6% on 207 closed (beat close 72%, t=4.6) · INDEPENDENT-close CLV +1.8% on 81 (beat 80%) · expected +11.30 vs actual -1.36
- 3★ · 94 bets (2 open) · 40-52 (win 43%) · ROI -9.3% · profit -13.06 · EV when placed +3.7% · CLV +1.2% on 88 closed (beat close 66%, t=1.8) · INDEPENDENT-close CLV +2.5% on 22 (beat 82%) · expected +5.59 vs actual -13.06
- 2½★ · 37 bets (0 open) · 15-22 (win 41%) · ROI -17.7% · profit -9.38 · EV when placed +3.2% · CLV +1.6% on 36 closed (beat close 75%, t=2.5) · INDEPENDENT-close CLV +1.9% on 18 (beat 78%) · expected +1.72 vs actual -9.38
- 2★ · 1 bets (0 open) · 1-0 (win 100%) · ROI +117.4% · profit +1.32 · EV when placed +2.9% · CLV n/a (no true close yet) · expected +0.03 vs actual +1.32
- 1½★ · 42 bets (16 open) · 14-12 (win 54%) · ROI -21.1% · profit -5.54 · EV when placed +3.0% · CLV -3.3% on 2 closed (beat close 0%) · no independent close · expected +0.77 vs actual -5.54
- Not rated · 490 bets (4 open) · 224-258-4 (win 46%) · ROI +0.0% · profit +0.18 · EV when placed +2.9% · CLV +0.2% on 385 closed (beat close 57%, t=0.5) · INDEPENDENT-close CLV +1.8% on 123 (beat 68%) · expected +13.33 vs actual -21.17

### Sharp book
- Not recorded · 595 bets (8 open) · 270-313-4 (win 46%) · ROI -2.0% · profit -13.95 · EV when placed +3.1% · CLV +0.4% on 457 closed (beat close 58%, t=1.1) · INDEPENDENT-close CLV +1.8% on 146 (beat 71%) · expected +19.48 vs actual -35.29
- A sharp book agreed · 648 bets (64 open) · 271-311-1 (win 47%) · ROI -1.9% · profit -17.22 · EV when placed +3.4% · CLV +2.1% on 599 closed (beat close 76%, t=9.2) · INDEPENDENT-close CLV +2.5% on 267 (beat 83%) · expected +31.91 vs actual -17.31
- No sharp book priced it · 72 bets (4 open) · 35-33 (win 51%) · ROI +11.4% · profit +10.33 · EV when placed +3.4% · CLV +1.1% on 63 closed (beat close 71%, t=1.2) · INDEPENDENT-close CLV +0.2% on 13 (beat 54%) · expected +3.22 vs actual +10.33
- A sharp book said no · 16 bets (0 open) · 3-13 (win 19%) · ROI -65.5% · profit -16.07 · EV when placed +3.1% · CLV +0.6% on 16 closed (beat close 63%, t=0.6) · INDEPENDENT-close CLV +1.1% on 8 (beat 63%) · expected +0.79 vs actual -16.07

### Books behind the fair
- 1 book · 38 bets (16 open) · 10-12 (win 45%) · ROI -26.0% · profit -5.78 · EV when placed +2.9% · CLV -3.3% on 2 closed (beat close 0%) · no independent close · expected +0.64 vs actual -5.78
- 2 books · 17 bets (0 open) · 6-11 (win 35%) · ROI -6.0% · profit -1.72 · EV when placed +3.9% · CLV +2.3% on 15 closed (beat close 73%, t=2.6) · INDEPENDENT-close CLV +2.7% on 3 (beat 67%) · expected +1.15 vs actual -1.72
- 3 books · 118 bets (6 open) · 45-67 (win 40%) · ROI -16.4% · profit -32.10 · EV when placed +3.8% · CLV +2.7% on 108 closed (beat close 77%, t=4.9) · INDEPENDENT-close CLV +2.3% on 27 (beat 74%) · expected +7.83 vs actual -32.10
- 4-5 books · 285 bets (15 open) · 127-141-1 (win 47%) · ROI -0.5% · profit -2.23 · EV when placed +3.5% · CLV +1.7% on 267 closed (beat close 75%, t=4.8) · INDEPENDENT-close CLV +2.2% on 76 (beat 82%) · expected +15.33 vs actual -2.31
- 6-9 books · 275 bets (23 open) · 120-132 (win 48%) · ROI -0.4% · profit -1.54 · EV when placed +3.4% · CLV +1.7% on 260 closed (beat close 73%, t=5.0) · INDEPENDENT-close CLV +2.3% on 144 (beat 80%) · expected +13.22 vs actual -1.54
- 10 or more books · 104 bets (12 open) · 43-49 (win 47%) · ROI +5.1% · profit +6.06 · EV when placed +2.9% · CLV +2.0% on 98 closed (beat close 79%, t=3.9) · INDEPENDENT-close CLV +2.9% on 61 (beat 89%) · expected +3.77 vs actual +6.06
- Not recorded · 494 bets (4 open) · 228-258-4 (win 47%) · ROI +0.1% · profit +0.42 · EV when placed +2.9% · CLV +0.2% on 385 closed (beat close 57%, t=0.5) · INDEPENDENT-close CLV +1.8% on 123 (beat 68%) · expected +13.47 vs actual -20.92

### Books agreeing
- Every book agreed · 438 bets (33 open) · 185-218-1 (win 46%) · ROI -3.8% · profit -23.36 · EV when placed +3.4% · CLV +2.1% on 411 closed (beat close 78%, t=6.9) · INDEPENDENT-close CLV +2.8% on 169 (beat 83%) · expected +21.47 vs actual -23.45
- All but one agreed · 34 bets (4 open) · 10-20 (win 33%) · ROI -20.6% · profit -8.38 · EV when placed +2.9% · CLV +0.3% on 32 closed (beat close 59%, t=0.3) · INDEPENDENT-close CLV +0.4% on 18 (beat 50%) · expected +1.26 vs actual -8.38
- Half or more agreed · 9 bets (1 open) · 4-4 (win 50%) · ROI +2.2% · profit +0.27 · EV when placed +3.0% · CLV -0.1% on 8 closed (beat close 75%, t=-0.0) · INDEPENDENT-close CLV -0.6% on 7 (beat 71%) · expected +0.40 vs actual +0.27
- Not recorded · 850 bets (38 open) · 380-428-4 (win 47%) · ROI -0.5% · profit -5.43 · EV when placed +3.2% · CLV +0.9% on 684 closed (beat close 63%, t=3.4) · INDEPENDENT-close CLV +2.0% on 240 (beat 76%) · expected +32.27 vs actual -26.77

### EV when placed
- Under 1% · 7 bets (0 open) · 3-4 (win 43%) · ROI +44.9% · profit +11.11 · EV when placed +0.3% · CLV -1.7% on 7 closed (beat close 29%, t=-1.1) · INDEPENDENT-close CLV +0.2% on 2 (beat 50%) · expected +0.03 vs actual -1.21
- 1–2% · 125 bets (4 open) · 56-64 (win 47%) · ROI -0.6% · profit -0.65 · EV when placed +1.6% · CLV +0.3% on 117 closed (beat close 56%, t=0.4) · INDEPENDENT-close CLV +2.6% on 43 (beat 70%) · expected +1.92 vs actual -0.65
- 2–3% · 365 bets (24 open) · 163-176-2 (win 48%) · ROI -0.6% · profit -2.47 · EV when placed +2.5% · CLV +0.6% on 324 closed (beat close 68%, t=1.6) · INDEPENDENT-close CLV +1.4% on 141 (beat 79%) · expected +10.20 vs actual -2.58
- 3–4% · 444 bets (31 open) · 193-219-1 (win 47%) · ROI +0.5% · profit +3.04 · EV when placed +3.5% · CLV +1.8% on 400 closed (beat close 73%, t=5.9) · INDEPENDENT-close CLV +2.3% on 162 (beat 78%) · expected +21.59 vs actual +3.08
- 4–6% · 297 bets (13 open) · 119-165 (win 42%) · ROI -12.3% · profit -56.98 · EV when placed +4.7% · CLV +2.1% on 263 closed (beat close 71%, t=4.8) · INDEPENDENT-close CLV +3.3% on 86 (beat 80%) · expected +21.66 vs actual -56.98
- 6% and up · 0 bets (0 open) · ROI n/a · profit +0.00 · EV when placed n/a · CLV n/a (no true close yet)
- No EV on record · 93 bets (4 open) · 45-42-2 (win 52%) · ROI +9.2% · profit +9.05 · EV when placed n/a · CLV +1.8% on 24 closed (beat close 58%, t=0.9) · no independent close

### Time before the game
- under 30 min · 118 bets (6 open) · 52-58-2 (win 47%) · ROI +3.4% · profit +5.03 · EV when placed +3.1% · CLV +3.6% on 117 closed (beat close 91%, t=13.6) · INDEPENDENT-close CLV +4.1% on 45 (beat 96%) · expected +4.59 vs actual +2.76
- 30 min-2 h · 135 bets (5 open) · 60-70 (win 46%) · ROI -7.0% · profit -13.50 · EV when placed +3.6% · CLV +3.0% on 127 closed (beat close 90%, t=11.8) · INDEPENDENT-close CLV +3.4% on 48 (beat 96%) · expected +6.90 vs actual -15.38
- 2-6 h · 274 bets (29 open) · 112-132 (win 46%) · ROI -2.2% · profit -7.81 · EV when placed +3.3% · CLV +2.3% on 249 closed (beat close 77%, t=9.0) · INDEPENDENT-close CLV +2.8% on 93 (beat 83%) · expected +11.93 vs actual -9.32
- 6-24 h · 441 bets (26 open) · 199-216 (win 48%) · ROI +1.3% · profit +8.02 · EV when placed +3.4% · CLV +0.6% on 343 closed (beat close 60%, t=1.8) · INDEPENDENT-close CLV +1.4% on 128 (beat 73%) · expected +18.76 vs actual +1.40
- 24 h or more · 336 bets (7 open) · 144-182-3 (win 44%) · ROI -5.7% · profit -23.52 · EV when placed +3.1% · CLV -0.3% on 299 closed (beat close 55%, t=-0.5) · INDEPENDENT-close CLV +1.4% on 120 (beat 64%) · expected +12.63 vs actual -32.67
- after the start · 27 bets (3 open) · 12-12 (win 50%) · ROI -26.1% · profit -5.12 · EV when placed +2.7% · CLV n/a (no true close yet) · expected +0.58 vs actual -5.12

### Liquidity
- Under $10 · 122 bets (7 open) · 53-61 (win 46%) · ROI +4.5% · profit +7.07 · EV when placed +3.7% · CLV +2.0% on 114 closed (beat close 75%, t=2.9) · INDEPENDENT-close CLV +2.6% on 40 (beat 83%) · expected +5.74 vs actual +7.07
- $10-25 · 65 bets (3 open) · 27-35 (win 44%) · ROI -14.9% · profit -13.14 · EV when placed +3.4% · CLV +2.0% on 64 closed (beat close 75%, t=3.1) · INDEPENDENT-close CLV +2.5% on 20 (beat 70%) · expected +3.23 vs actual -13.14
- $25-100 · 136 bets (3 open) · 63-70 (win 47%) · ROI -1.3% · profit -2.75 · EV when placed +3.3% · CLV +2.1% on 134 closed (beat close 81%, t=4.3) · INDEPENDENT-close CLV +2.0% on 71 (beat 82%) · expected +7.16 vs actual -2.75
- $100-500 · 157 bets (16 open) · 60-80-1 (win 43%) · ROI -12.2% · profit -28.61 · EV when placed +3.4% · CLV +1.7% on 140 closed (beat close 74%, t=3.8) · INDEPENDENT-close CLV +2.7% on 63 (beat 79%) · expected +8.03 vs actual -28.70
- $500 or more · 82 bets (11 open) · 31-40 (win 44%) · ROI -3.0% · profit -3.35 · EV when placed +3.6% · CLV +1.2% on 71 closed (beat close 68%, t=1.7) · INDEPENDENT-close CLV +2.4% on 23 (beat 83%) · expected +4.58 vs actual -3.35
- Not recorded · 769 bets (36 open) · 345-384-4 (win 47%) · ROI +0.4% · profit +3.87 · EV when placed +3.1% · CLV +0.9% on 612 closed (beat close 63%, t=2.9) · INDEPENDENT-close CLV +2.0% on 217 (beat 75%) · expected +26.67 vs actual -17.47

### Odds
- Underdog (+110 to +200) · 735 bets (29 open) · 294-410-2 (win 42%) · ROI -8.0% · profit -74.33 · EV when placed +3.5% · CLV +1.4% on 634 closed (beat close 67%, t=4.7) · INDEPENDENT-close CLV +2.5% on 233 (beat 77%) · expected +31.63 vs actual -67.92
- Even money (−110 to +110) · 449 bets (34 open) · 208-206 (win 50%) · ROI +1.0% · profit +5.96 · EV when placed +3.0% · CLV +1.2% on 391 closed (beat close 71%, t=3.9) · INDEPENDENT-close CLV +1.7% on 156 (beat 78%) · expected +17.49 vs actual -10.72
- Favorite (−200 to −110) · 133 bets (9 open) · 71-50-3 (win 59%) · ROI +16.7% · profit +34.88 · EV when placed +3.0% · CLV +1.5% on 107 closed (beat close 69%, t=3.4) · INDEPENDENT-close CLV +2.4% on 45 (beat 78%) · expected +5.87 vs actual +24.07
- Heavy favorite (−200 or shorter) · 9 bets (0 open) · 6-3 (win 67%) · ROI -19.5% · profit -2.71 · EV when placed +3.0% · CLV -5.0% on 2 closed (beat close 0%) · no independent close · expected +0.37 vs actual -3.06
- Long shot (over +200) · 5 bets (4 open) · 0-1 (win 0%) · ROI -100.0% · profit -0.71 · EV when placed +3.8% · CLV -4.5% on 1 closed (beat close 0%) · no independent close · expected +0.04 vs actual -0.71

### Scanner
- CNO · 825 bets (14 open) · 371-436-3 (win 46%) · ROI -2.8% · profit -30.81 · EV when placed +3.1% · CLV +1.2% on 729 closed (beat close 68%, t=4.2) · INDEPENDENT-close CLV +2.0% on 300 (beat 74%) · expected +33.46 vs actual -46.32
- Vigilant · 480 bets (60 open) · 195-223-2 (win 47%) · ROI -0.6% · profit -3.78 · EV when placed +3.5% · CLV +1.7% on 405 closed (beat close 69%, t=6.1) · INDEPENDENT-close CLV +2.7% on 134 (beat 85%) · expected +21.28 vs actual -9.70
- Live bids · 17 bets (2 open) · 5-10 (win 33%) · ROI -48.8% · profit -5.39 · EV when placed +2.5% · CLV n/a (no true close yet) · expected +0.30 vs actual -5.39
- Live tail · 4 bets (0 open) · 4-0 (win 100%) · ROI +6.3% · profit +0.25 · EV when placed +3.5% · CLV n/a (no true close yet) · expected +0.14 vs actual +0.25
- Pinnodds live · 3 bets (0 open) · 2-1 (win 67%) · ROI +10.6% · profit +0.32 · EV when placed +3.5% · CLV n/a (no true close yet) · expected +0.10 vs actual +0.32
- ParlayAPI · 2 bets (0 open) · 2-0 (win 100%) · ROI +125.9% · profit +2.51 · EV when placed +5.9% · CLV -10.1% on 1 closed (beat close 0%) · no independent close · expected +0.12 vs actual +2.51

### Close basis
- history:pinnacle · 418 bets (18 open) · 183-216-1 (win 46%) · ROI -3.5% · profit -20.41 · EV when placed +3.2% · CLV +2.2% on 418 closed (beat close 78%, t=7.5) · INDEPENDENT-close CLV +2.2% on 418 (beat 78%) · expected +19.45 vs actual -20.44
- history:novig-trades · 276 bets (0 open) · 128-146-2 (win 47%) · ROI +3.0% · profit +11.10 · EV when placed +3.1% · CLV -0.2% on 276 closed (beat close 50%, t=-0.4) · no independent close · expected +11.64 vs actual -2.22
- No true close yet · 196 bets (42 open) · 68-84-1 (win 45%) · ROI -8.4% · profit -15.90 · EV when placed +3.4% · CLV n/a (no true close yet) · expected +3.94 vs actual -29.40
- read:cno · 233 bets (2 open) · 109-121-1 (win 47%) · ROI -2.0% · profit -6.79 · EV when placed +3.3% · CLV +1.2% on 233 closed (beat close 72%, t=2.1) · no independent close · expected +11.74 vs actual -6.88
- read:vigilant · 160 bets (5 open) · 71-84 (win 46%) · ROI -1.9% · profit -4.10 · EV when placed +3.5% · CLV +1.6% on 160 closed (beat close 68%, t=4.3) · no independent close · expected +7.12 vs actual +1.40
- read:both · 32 bets (9 open) · 10-13 (win 43%) · ROI -19.4% · profit -5.92 · EV when placed +3.4% · CLV +2.7% on 32 closed (beat close 84%, t=3.6) · no independent close · expected +1.07 vs actual -5.92
- history:espn · 16 bets (0 open) · 10-6 (win 63%) · ROI +28.3% · profit +5.12 · EV when placed +2.4% · CLV +3.4% on 16 closed (beat close 81%, t=3.9) · INDEPENDENT-close CLV +3.4% on 16 (beat 81%) · expected +0.45 vs actual +5.12

### By week placed
- week of 2026-09-21 · 130 bets (0 open) · 69-61 (win 53%) · ROI +9.8% · profit +12.83 · EV when placed +2.7% · CLV +1.2% on 64 closed (beat close 59%, t=1.6) · INDEPENDENT-close CLV +3.7% on 20 (beat 85%) · expected +1.82 vs actual +6.51
- week of 2026-09-28 · 475 bets (0 open) · 213-259-3 (win 45%) · ROI -2.6% · profit -16.26 · EV when placed +3.1% · CLV +0.3% on 440 closed (beat close 61%, t=0.8) · INDEPENDENT-close CLV +1.6% on 166 (beat 70%) · expected +19.56 vs actual -30.26
- week of 2026-10-05 · 726 bets (76 open) · 297-350-2 (win 46%) · ROI -3.5% · profit -33.47 · EV when placed +3.5% · CLV +2.0% on 631 closed (beat close 75%, t=10.4) · INDEPENDENT-close CLV +2.5% on 248 (beat 82%) · expected +34.02 vs actual -34.58

## Automatic findings (closing-line value, strongest evidence first)
### Beating the close
- Sharp book = A sharp book agreed AND Time before the game = under 30 min: CLV +3.9% on 80 closed (t=14.3, beat close 95%) · ROI -2.5% · profit -2.61
- Time before the game = under 30 min: CLV +3.6% on 117 closed (t=13.6, beat close 91%) · ROI +4.1% · profit +5.93
- Auto or manual = Auto AND Time before the game = under 30 min: CLV +3.6% on 64 closed (t=13.1, beat close 94%) · ROI +2.3% · profit +1.83
- Type of bet = Player props AND Time before the game = under 30 min: CLV +3.8% on 89 closed (t=13.0, beat close 94%) · ROI +5.2% · profit +5.89
- Bet or bid = Bets (taker orders) AND Time before the game = under 30 min: CLV +3.7% on 96 closed (t=12.9, beat close 92%) · ROI +3.0% · profit +3.80
- Time before the game = 30 min-2 h: CLV +3.0% on 127 closed (t=11.8, beat close 90%) · ROI -3.5% · profit -6.23
- Sport = Football AND Time before the game = under 30 min: CLV +3.6% on 71 closed (t=11.8, beat close 94%) · ROI +1.8% · profit +1.50
- Type of bet = Player props AND Time before the game = 30 min-2 h: CLV +3.1% on 105 closed (t=11.6, beat close 92%) · ROI -8.4% · profit -12.65
- Time before the game = under 30 min AND Scanner = CNO: CLV +3.9% on 72 closed (t=11.4, beat close 90%) · ROI +2.1% · profit +2.17
- Books behind the fair = 4-5 books AND Time before the game = under 30 min: CLV +4.3% on 30 closed (t=11.4, beat close 97%) · ROI -5.8% · profit -2.50
- Time before the game = under 30 min AND Odds = Underdog (+110 to +200): CLV +4.3% on 64 closed (t=10.9, beat close 88%) · ROI -6.3% · profit -4.70
- Star rating = 4½★ AND Time before the game = 2-6 h: CLV +4.1% on 37 closed (t=10.7, beat close 97%) · ROI -31.5% · profit -17.60
- Star rating = 4★ AND Time before the game = under 30 min: CLV +3.9% on 39 closed (t=10.3, beat close 95%) · ROI +5.7% · profit +3.05
- Time before the game = under 30 min AND Odds = Even money (−110 to +110): CLV +2.7% on 45 closed (t=10.3, beat close 96%) · ROI +1.8% · profit +1.07
- Auto or manual = Auto: CLV +2.1% on 566 closed (t=10.2, beat close 76%) · ROI +1.7% · profit +14.02
### Giving the close away
- Type of bet = Spreads AND Odds = Even money (−110 to +110): CLV -3.5% on 33 closed (t=-1.8, beat close 42%) · ROI +24.3% · profit +8.87
- Type of bet = Spreads AND EV when placed = 1–2%: CLV -3.5% on 29 closed (t=-1.8, beat close 38%) · ROI -26.1% · profit -7.44
- EV when placed = 1–2% AND Odds = Even money (−110 to +110): CLV -1.5% on 64 closed (t=-1.5, beat close 58%) · ROI -3.3% · profit -2.08
- Type of bet = Game totals AND Odds = Even money (−110 to +110): CLV -2.1% on 33 closed (t=-1.5, beat close 39%) · ROI +15.2% · profit +5.49
- Time before the game = 24 h or more AND Odds = Even money (−110 to +110): CLV -1.5% on 87 closed (t=-1.5, beat close 46%) · ROI -0.3% · profit -0.28
- EV when placed = 2–3% AND Time before the game = 24 h or more: CLV -1.2% on 96 closed (t=-1.2, beat close 53%) · ROI -3.1% · profit -3.25
- Sport = College football AND Odds = Even money (−110 to +110): CLV -1.4% on 52 closed (t=-1.1, beat close 56%) · ROI +34.2% · profit +20.49
- Auto or manual = Manual AND Type of bet = Spreads: CLV -1.3% on 73 closed (t=-1.0, beat close 49%) · ROI +23.8% · profit +19.23
- EV when placed = 1–2% AND Time before the game = 6-24 h: CLV -0.9% on 31 closed (t=-1.0, beat close 42%) · ROI -20.4% · profit -6.29
- Time before the game = 24 h or more AND Liquidity = $100-500: CLV -1.6% on 30 closed (t=-1.0, beat close 40%) · ROI -11.6% · profit -5.81
- Type of bet = Spreads AND Time before the game = 24 h or more: CLV -1.5% on 59 closed (t=-1.0, beat close 49%) · ROI +26.3% · profit +17.14
- Sport = College football AND Time before the game = 24 h or more: CLV -1.1% on 72 closed (t=-0.9, beat close 51%) · ROI +23.6% · profit +17.98
- Auto or manual = Manual AND Time before the game = 24 h or more: CLV -0.6% on 232 closed (t=-0.9, beat close 52%) · ROI -1.8% · profit -4.78
- Books behind the fair = 4-5 books AND Time before the game = 24 h or more: CLV -1.7% on 27 closed (t=-0.8, beat close 48%) · ROI -30.8% · profit -12.08
- EV when placed = 3–4% AND Time before the game = 24 h or more: CLV -0.8% on 83 closed (t=-0.8, beat close 52%) · ROI -19.9% · profit -21.15
(t = mean CLV over its standard error: |t| of 2+ is hard to get by luck for one group, but this scans 1355 groups, so expect some at |t| of 2-3 by chance alone: trust the ones that are large AND make sense, and that hold on `closeIndependent: true` bets.)

## Bids posted (all, filled or not)
- All bids · 22234 posted · 245 filled (1%), 218 fully · $383.22 paid · median time to first fill 94s · picked off (fair under price at the fill) 1% of 231 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- status canceled: 21205
- status expired: 794
- status filled: 218
- status refused: 16
- status lost: 1
### By kind
- Player props · 11924 posted · 174 filled (1%), 152 fully · $277.49 paid · median time to first fill 86s · picked off (fair under price at the fill) 1% of 167 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- Team totals · 8589 posted · 65 filled (1%), 61 fully · $99.22 paid · median time to first fill 133s · picked off (fair under price at the fill) 2% of 59 judged, mean fill EV +3.7% · mean EV at posting +3.8%
- 1st half / inning / set lines · 961 posted · 4 filled (0%), 4 fully · $4.87 paid · median time to first fill 106s · picked off (fair under price at the fill) 0% of 4 judged, mean fill EV +2.8% · mean EV at posting +3.1%
- Game totals · 416 posted · 1 filled (0%), 1 fully · $0.71 paid · mean EV at posting +3.3%
- Spreads · 278 posted · 0 filled (0%), 0 fully · $0.00 paid · mean EV at posting +3.0%
- Moneylines · 66 posted · 1 filled (2%), 0 fully · $0.93 paid · median time to first fill 2s · picked off (fair under price at the fill) 0% of 1 judged, mean fill EV +1.0% · mean EV at posting +2.6%
### By time before the start when posted
- under 30 min · 608 posted · 14 filled (2%), 12 fully · $14.88 paid · median time to first fill 93s · picked off (fair under price at the fill) 0% of 13 judged, mean fill EV +3.1% · mean EV at posting +3.5%
- 30 min-2 h · 1603 posted · 36 filled (2%), 32 fully · $57.10 paid · median time to first fill 91s · picked off (fair under price at the fill) 0% of 35 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- 2-6 h · 5682 posted · 81 filled (1%), 73 fully · $111.13 paid · median time to first fill 104s · picked off (fair under price at the fill) 3% of 77 judged, mean fill EV +3.3% · mean EV at posting +3.6%
- 6-24 h · 11513 posted · 112 filled (1%), 99 fully · $197.04 paid · median time to first fill 93s · picked off (fair under price at the fill) 0% of 104 judged, mean fill EV +3.6% · mean EV at posting +3.6%
- 24 h or more · 2828 posted · 2 filled (0%), 2 fully · $3.07 paid · median time to first fill 9s · picked off (fair under price at the fill) 0% of 2 judged, mean fill EV +2.8% · mean EV at posting +3.8%
### By scanner / auto
- vigilant (auto) · 22018 posted · 236 filled (1%), 211 fully · $363.82 paid · median time to first fill 102s · picked off (fair under price at the fill) 1% of 222 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- cno (auto) · 216 posted · 9 filled (4%), 7 fully · $19.41 paid · median time to first fill 2s · picked off (fair under price at the fill) 0% of 9 judged, mean fill EV +3.7% · mean EV at posting +3.5%

## Data quality
- without the record as placed (older or imported bets): 514 of 1422 (36%)
- with a recorded star rating (rated live): 91 of 1422 (6%)
- with an estimated star rating: 817 of 1422 (57%)
- with no star rating possible: 514 of 1422 (36%)
- started but with no true close: 193 of 1422 (14%)
- left out of the averages as outliers: 80 of 1422 (6%)
- open: 83 of 1422 (6%)
- true closes by basis: history:pinnacle 424, history:novig-trades 292, read:cno 240, read:vigilant 172, read:both 34, history:espn 16

