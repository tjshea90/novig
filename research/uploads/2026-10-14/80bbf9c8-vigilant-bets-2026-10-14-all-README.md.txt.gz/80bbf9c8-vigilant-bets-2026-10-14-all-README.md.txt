# Vigilant bet history (everything)

Generated 2026-10-14T01:40:37.235-04:00 by Vigilant (format 1). **1915 bets and bid fills** (452 are bid fills), **49986 bids posted**, from 2026-09-25 to 2026-10-14.

## Your task
Tj bets on Novig (a US exchange) with a +EV scanner, **Vigilant**. The goal is PROFIT through positive EV that the CLOSING LINE confirms. From the files below find (1) which kinds of bets and bids beat the close and are
profitable and which do not, (2) whether the app's own star rating, sharp-book check and agreement counts predict beating the close, (3) specific filters, thresholds and rule changes for the auto-bet
and the auto-bid desk (name the setting or the code: Presets.kt, SharpVeto.kt, AutoBet.kt, MakerRules.kt, BetRating.kt), (4) data-quality problems in the logging itself. Judge groups by CLV first (it needs far fewer
bets than profit to say anything): a group wants roughly 100+ bets with a true close before CLV means much and 1,000+ before ROI does. State the sample size and t-statistic behind every claim, say when the sample is too small, and
do not recommend a change on a handful of bets. Bets and bids are different instruments (a bid can be picked off; a bet cannot): read them apart.

## Files
- `vigilant-bets-2026-10-14-all-bets-p1.jsonl`: bets and bid fills, one JSON object per line, oldest first
- `vigilant-bets-2026-10-14-all-bids-posted-p1.jsonl`: every bid posted (filled or not), one JSON object per line
- this README: dictionary, definitions, summary tables and automatic findings

## Definitions
- **Odds** are American. `cost` is the price paid per $1 of payout including Novig's taker fee (a pregame taker fee is 0; a bid pays no fee). EV, CLV, ROI, fair and win % are fractions (0.03 = +3%).
- **EV** (`ev`): `fair / cost - 1` at the moment of placing, against the fair chance the app had then (devigged books). For a bid it is the edge at its fair when it was POSTED.
- **Fair** (`fair`, `fairOdds`): the no-vig chance of the bet's side from the books (worst-case devig, lower of mean and median; sister sites count once; books with wrong-looking odds are left out).
- **Close and CLV**: `closeFair` is the same side's no-vig chance at the START of the game; `closeOdds` is that as American odds (a fair price, not a book price: do not compare it with `odds` without the vig in mind - `clv` already does). `clv = closeFair / cost - 1`:
  positive = the bet was cheaper than the market's final opinion. It exists ONLY for a TRUE close: a read of the market in the last 15 minutes before the start made at least 60 s after the bet (a read seconds after the bet is its own line, not a close), or a history source's price at the start. `closeSource` = captured or the history source.
  `closeBasis` says what the close is made of: `read:cno` (CrazyNinjaOdds' consensus, the SAME kind of consensus that found most CNO bets), `read:vigilant` (Vigilant's own fair line), `read:both`, `history:pinnacle` (Pinnacle's price at the start, via ParlayAPI/SGO/OddsPapi), `history:espn`, `history:novig-trades` (the last 3+ trades on Novig in the last 15 minutes, the bettor's own fills included).
  `closeIndependent` = true only for history from another source than the one that found the bet (a sharp book's price at the start, or ESPN's): CLV against `read:cno` is partly circular (the bet and its close come from one consensus), so **test every CLV claim on `closeIndependent: true` bets too**. When both exist the sharp book's price at the start is the close (the app asks for it even when a read before the start exists); `startsLoggedMs`/`startsNote` appear when a game started early or late and the start was corrected. For a read, `closeReadMs`/`closeLeadSec` say when it was taken and how many seconds before the start, `closeReadAfterBetSec` how long after the bet; a history close has no read time (it is the price at the start).
  Closes found after the game are devigged by the same conservative WORST-CASE method as the app's own fair (the lowest fair chance of four methods; `AtBet`'s `fairMethod` says which method priced each bet: bets before v0.89.19 used POWER); before v0.89.18 history closes were multiplicative, which flatters longshots by 5-13% (so very old history closes on dogs are biased high). `novigCloseOdds`/`novigCloseAgeSec` = Novig's own last price when it was read in the last 15 minutes before the start.
- **Stars** (`stars`, 1-5 in halves): the app's rating of how much to TRUST the edge: companies pricing both sides (20 points), share agreeing +EV (20), size of the edge (25, falling above 12%), a sharp book agreeing (25), tightness of the books' fair chances (10); ceilings by company count and a sharp book against. `starsBasis` = recorded (rated live) or estimated (worked out afterwards from the record, notably every bid and every bet before v0.89.17).
- **books / booksAgree**: companies (sister sites once) pricing BOTH sides behind the fair, and how many of those said +EV on their own. `sharp`: agree / against / none (no sharp book priced it); absent = not recorded.
- **how**: auto (auto-bet or auto-bid) / manual / lock. **made**: bet (taker) / bid (maker fill). **leadMin**: minutes before the start when placed. **liquidity**: dollars Novig had at the price. **result**: won / lost / push / void / fmv / open; **profit** in dollars, **roi** = profit/stake.
- `outlier: true` = an EV beyond +-6% that the app leaves out of its averages (so do the tables here); `lockFor` = a bet that locks in another's profit (not a pick).
- A field absent from a line is unknown for that bet (never 0 or empty). Times are America/New_York.

## Headline
**Read the INDEPENDENT-close CLV first**: a close read from the market before the start is, for a CrazyNinjaOdds bet, the same consensus that found it (partly circular); the independent figure (a sharp book's or ESPN's price at the start) cannot be.
- All · 1783 bets (122 open) · 748-902-10 (win 45%) · ROI -4.4% · profit -92.54 · EV when placed +3.3% · CLV +1.3% on 1446 closed (beat close 70%, t=7.1) · INDEPENDENT-close CLV +2.2% on 585 (beat 77%) · expected +67.92 vs actual -109.87
- Bets (taker orders) · 1331 bets (106 open) · 541-676-7 (win 44%) · ROI -6.3% · profit -97.94 · EV when placed +3.2% · CLV +1.0% on 1078 closed (beat close 68%, t=4.2) · INDEPENDENT-close CLV +1.9% on 447 (beat 74%) · expected +48.96 vs actual -112.86
- Bid fills · 452 bets (16 open) · 207-226-3 (win 48%) · ROI +1.0% · profit +5.40 · EV when placed +3.6% · CLV +2.3% on 368 closed (beat close 75%, t=9.0) · INDEPENDENT-close CLV +3.1% on 138 (beat 85%) · expected +18.96 vs actual +3.00

## Splits (every dimension on its own)
### Bet or bid
- Bets (taker orders) · 1331 bets (106 open) · 541-676-7 (win 44%) · ROI -6.3% · profit -97.94 · EV when placed +3.2% · CLV +1.0% on 1078 closed (beat close 68%, t=4.2) · INDEPENDENT-close CLV +1.9% on 447 (beat 74%) · expected +48.96 vs actual -112.86
- Bids (make orders that filled) · 452 bets (16 open) · 207-226-3 (win 48%) · ROI +1.0% · profit +5.40 · EV when placed +3.6% · CLV +2.3% on 368 closed (beat close 75%, t=9.0) · INDEPENDENT-close CLV +3.1% on 138 (beat 85%) · expected +18.96 vs actual +3.00

### Auto or manual
- Manual · 872 bets (51 open) · 365-447-9 (win 45%) · ROI -7.1% · profit -67.92 · EV when placed +3.1% · CLV +0.7% on 701 closed (beat close 64%, t=2.5) · INDEPENDENT-close CLV +2.0% on 284 (beat 74%) · expected +27.67 vs actual -74.22
- Auto · 911 bets (71 open) · 383-455-1 (win 46%) · ROI -3.3% · profit -36.93 · EV when placed +3.4% · CLV +1.8% on 745 closed (beat close 75%, t=8.3) · INDEPENDENT-close CLV +2.4% on 301 (beat 80%) · expected +40.26 vs actual -35.64
- Lock (profit locked in) · 0 bets (0 open) · ROI +79.3% · profit +12.31 · EV when placed n/a · CLV n/a (no true close yet)

### Type of bet
- Player props · 1141 bets (40 open) · 478-616-6 (win 44%) · ROI -8.9% · profit -129.90 · EV when placed +3.4% · CLV +1.7% on 996 closed (beat close 73%, t=8.8) · INDEPENDENT-close CLV +2.2% on 455 (beat 80%) · expected +49.13 vs actual -144.23
- Spreads · 191 bets (30 open) · 74-86-1 (win 46%) · ROI +3.7% · profit +6.87 · EV when placed +2.8% · CLV -1.4% on 135 closed (beat close 57%, t=-1.5) · INDEPENDENT-close CLV +1.3% on 36 (beat 61%) · expected +5.57 vs actual +4.53
- Game totals · 196 bets (37 open) · 80-79 (win 50%) · ROI +7.3% · profit +11.88 · EV when placed +2.9% · CLV +0.2% on 121 closed (beat close 50%, t=0.3) · INDEPENDENT-close CLV +1.9% on 33 (beat 58%) · expected +4.60 vs actual +10.84
- Team totals · 133 bets (6 open) · 69-58 (win 54%) · ROI +18.4% · profit +29.60 · EV when placed +3.5% · CLV +2.9% on 127 closed (beat close 80%, t=8.0) · INDEPENDENT-close CLV +2.9% on 38 (beat 82%) · expected +5.93 vs actual +28.56
- Moneylines · 67 bets (6 open) · 23-38 (win 38%) · ROI -29.8% · profit -16.80 · EV when placed +3.2% · CLV -2.7% on 23 closed (beat close 48%, t=-0.8) · INDEPENDENT-close CLV +2.5% on 15 (beat 60%) · expected +1.91 vs actual -16.80
- 1st half / inning / set lines · 28 bets (3 open) · 13-12 (win 52%) · ROI +22.6% · profit +6.12 · EV when placed +3.0% · CLV +2.6% on 25 closed (beat close 68%, t=2.4) · INDEPENDENT-close CLV +4.2% on 8 (beat 88%) · expected +0.77 vs actual +6.49
- Other · 27 bets (0 open) · 11-13-3 (win 46%) · ROI -0.8% · profit -0.30 · EV when placed +2.3% · CLV +1.2% on 19 closed (beat close 58%, t=0.5) · no independent close · expected +0.02 vs actual +0.75

### Sport
- Football · 673 bets (34 open) · 278-358-3 (win 44%) · ROI -9.8% · profit -84.93 · EV when placed +3.2% · CLV +1.3% on 599 closed (beat close 70%, t=4.2) · INDEPENDENT-close CLV +2.1% on 253 (beat 77%) · expected +28.45 vs actual -89.34
- Hockey · 372 bets (11 open) · 171-189 (win 48%) · ROI -1.5% · profit -6.73 · EV when placed +3.4% · CLV +2.5% on 356 closed (beat close 79%, t=10.6) · INDEPENDENT-close CLV +2.5% on 204 (beat 80%) · expected +16.06 vs actual -8.12
- College football · 222 bets (45 open) · 92-85 (win 52%) · ROI +19.7% · profit +40.38 · EV when placed +2.9% · CLV +0.4% on 164 closed (beat close 61%, t=0.6) · INDEPENDENT-close CLV +3.0% on 36 (beat 78%) · expected +6.39 vs actual +39.27
- Basketball · 181 bets (10 open) · 73-98 (win 43%) · ROI -10.5% · profit -22.11 · EV when placed +3.2% · CLV -0.5% on 147 closed (beat close 62%, t=-0.6) · INDEPENDENT-close CLV +0.8% on 44 (beat 66%) · expected +7.19 vs actual -24.50
- Baseball · 166 bets (12 open) · 69-79-6 (win 47%) · ROI -0.3% · profit -0.69 · EV when placed +3.5% · CLV +1.2% on 136 closed (beat close 67%, t=2.8) · INDEPENDENT-close CLV +2.1% on 39 (beat 74%) · expected +6.76 vs actual -5.97
- Tennis · 97 bets (10 open) · 27-59-1 (win 31%) · ROI -28.3% · profit -24.56 · EV when placed +3.5% · CLV +2.3% on 35 closed (beat close 69%, t=2.1) · INDEPENDENT-close CLV +4.8% on 9 (beat 56%) · expected +3.03 vs actual -23.28
- Other · 70 bets (0 open) · 36-34 (win 51%) · ROI +5.4% · profit +4.01 · EV when placed n/a · CLV -2.9% on 7 closed (beat close 0%, t=-3.8) · no independent close
- Soccer · 2 bets (0 open) · 2-0 (win 100%) · ROI +105.0% · profit +2.09 · EV when placed +2.3% · CLV +0.9% on 2 closed (beat close 50%) · no independent close · expected +0.05 vs actual +2.09

### Star rating
- 5★ · 26 bets (6 open) · 3-16-1 (win 16%) · ROI -67.8% · profit -19.37 · EV when placed +4.7% · CLV +1.2% on 18 closed (beat close 78%, t=0.6) · INDEPENDENT-close CLV +4.1% on 10 (beat 90%) · expected +1.33 vs actual -19.60
- 4½★ · 229 bets (30 open) · 74-124-1 (win 37%) · ROI -17.6% · profit -51.17 · EV when placed +3.6% · CLV +1.5% on 194 closed (beat close 79%, t=2.7) · INDEPENDENT-close CLV +3.0% on 101 (beat 85%) · expected +11.14 vs actual -51.21
- 4★ · 469 bets (55 open) · 199-213-1 (win 48%) · ROI +3.0% · profit +15.89 · EV when placed +3.1% · CLV +1.7% on 409 closed (beat close 73%, t=5.6) · INDEPENDENT-close CLV +1.8% on 188 (beat 74%) · expected +17.63 vs actual +15.80
- 3½★ · 309 bets (16 open) · 141-151-1 (win 48%) · ROI +0.3% · profit +0.97 · EV when placed +3.5% · CLV +1.9% on 276 closed (beat close 74%, t=6.2) · INDEPENDENT-close CLV +2.1% on 112 (beat 80%) · expected +13.67 vs actual +1.00
- 3★ · 126 bets (12 open) · 47-67 (win 41%) · ROI -11.4% · profit -17.97 · EV when placed +3.5% · CLV +2.0% on 106 closed (beat close 69%, t=3.0) · INDEPENDENT-close CLV +4.1% on 32 (beat 84%) · expected +6.17 vs actual -17.97
- 2½★ · 41 bets (1 open) · 16-24 (win 40%) · ROI -17.5% · profit -9.41 · EV when placed +3.2% · CLV +1.7% on 40 closed (beat close 75%, t=3.0) · INDEPENDENT-close CLV +2.1% on 19 (beat 79%) · expected +1.75 vs actual -9.41
- 2★ · 1 bets (0 open) · 1-0 (win 100%) · ROI +117.4% · profit +1.32 · EV when placed +2.9% · CLV -5.4% on 1 closed (beat close 0%) · no independent close · expected +0.03 vs actual +1.32
- 1½★ · 87 bets (2 open) · 40-44-1 (win 48%) · ROI -12.1% · profit -9.91 · EV when placed +3.6% · CLV +1.4% on 12 closed (beat close 75%, t=1.4) · no independent close · expected +2.87 vs actual -8.63
- Not rated · 495 bets (0 open) · 227-263-5 (win 46%) · ROI -0.5% · profit -2.88 · EV when placed +2.9% · CLV +0.2% on 390 closed (beat close 57%, t=0.4) · INDEPENDENT-close CLV +1.8% on 123 (beat 68%) · expected +13.33 vs actual -21.17

### Sharp book
- A sharp book agreed · 1022 bets (107 open) · 406-503-5 (win 45%) · ROI -5.9% · profit -70.94 · EV when placed +3.3% · CLV +1.8% on 879 closed (beat close 76%, t=8.6) · INDEPENDENT-close CLV +2.4% on 406 (beat 81%) · expected +41.98 vs actual -69.98
- Not recorded · 634 bets (0 open) · 291-338-5 (win 46%) · ROI -2.3% · profit -17.52 · EV when placed +3.2% · CLV +0.4% on 463 closed (beat close 58%, t=1.0) · INDEPENDENT-close CLV +1.8% on 146 (beat 71%) · expected +20.78 vs actual -35.80
- No sharp book priced it · 111 bets (15 open) · 48-48 (win 50%) · ROI +10.2% · profit +11.99 · EV when placed +3.6% · CLV +1.5% on 88 closed (beat close 69%, t=1.8) · INDEPENDENT-close CLV +1.4% on 25 (beat 56%) · expected +4.37 vs actual +11.99
- A sharp book said no · 16 bets (0 open) · 3-13 (win 19%) · ROI -65.5% · profit -16.07 · EV when placed +3.1% · CLV +0.6% on 16 closed (beat close 63%, t=0.6) · INDEPENDENT-close CLV +1.1% on 8 (beat 63%) · expected +0.79 vs actual -16.07

### Books behind the fair
- 1 book · 82 bets (1 open) · 36-44-1 (win 45%) · ROI -13.0% · profit -10.16 · EV when placed +3.5% · CLV +1.4% on 12 closed (beat close 75%, t=1.4) · no independent close · expected +2.73 vs actual -8.87
- 2 books · 26 bets (2 open) · 9-15 (win 38%) · ROI -5.8% · profit -2.09 · EV when placed +4.0% · CLV +3.8% on 20 closed (beat close 75%, t=2.0) · INDEPENDENT-close CLV +10.0% on 5 (beat 80%) · expected +1.44 vs actual -2.09
- 3 books · 155 bets (9 open) · 61-85 (win 42%) · ROI -10.1% · profit -23.49 · EV when placed +3.8% · CLV +2.4% on 133 closed (beat close 77%, t=4.2) · INDEPENDENT-close CLV +2.5% on 39 (beat 74%) · expected +9.12 vs actual -23.49
- 4-5 books · 367 bets (20 open) · 155-190-1 (win 45%) · ROI -5.3% · profit -26.66 · EV when placed +3.5% · CLV +1.4% on 336 closed (beat close 71%, t=4.0) · INDEPENDENT-close CLV +1.8% on 113 (beat 75%) · expected +18.09 vs actual -26.75
- 6-9 books · 423 bets (45 open) · 176-201-1 (win 47%) · ROI -3.7% · profit -18.02 · EV when placed +3.3% · CLV +1.4% on 365 closed (beat close 74%, t=4.3) · INDEPENDENT-close CLV +2.3% on 198 (beat 80%) · expected +17.20 vs actual -18.25
- 10 or more books · 230 bets (44 open) · 80-104-2 (win 43%) · ROI -5.1% · profit -9.49 · EV when placed +2.9% · CLV +2.1% on 190 closed (beat close 78%, t=6.5) · INDEPENDENT-close CLV +2.5% on 107 (beat 83%) · expected +5.88 vs actual -9.50
- Not recorded · 500 bets (1 open) · 231-263-5 (win 47%) · ROI -0.5% · profit -2.63 · EV when placed +2.9% · CLV +0.2% on 390 closed (beat close 57%, t=0.4) · INDEPENDENT-close CLV +1.8% on 123 (beat 68%) · expected +13.47 vs actual -20.92

### Books agreeing
- Every book agreed · 656 bets (75 open) · 251-326-3 (win 44%) · ROI -7.1% · profit -55.76 · EV when placed +3.3% · CLV +1.5% on 555 closed (beat close 75%, t=4.9) · INDEPENDENT-close CLV +2.3% on 252 (beat 78%) · expected +27.73 vs actual -56.11
- All but one agreed · 76 bets (14 open) · 23-39 (win 37%) · ROI -19.1% · profit -12.04 · EV when placed +2.9% · CLV +0.8% on 60 closed (beat close 68%, t=1.2) · INDEPENDENT-close CLV +0.8% on 35 (beat 63%) · expected +1.92 vs actual -12.04
- Half or more agreed · 41 bets (16 open) · 11-14 (win 44%) · ROI -18.1% · profit -4.88 · EV when placed +2.9% · CLV +1.4% on 25 closed (beat close 76%, t=1.2) · INDEPENDENT-close CLV +1.5% on 18 (beat 83%) · expected +0.86 vs actual -4.88
- Under half agreed · 1 bets (0 open) · 0-0-1 (win n/a) · ROI -4.0% · profit -0.02 · EV when placed +3.1% · CLV +6.2% on 1 closed (beat close 100%) · no independent close
- Not recorded · 1009 bets (17 open) · 463-523-6 (win 47%) · ROI -1.6% · profit -19.84 · EV when placed +3.3% · CLV +1.2% on 805 closed (beat close 66%, t=4.9) · INDEPENDENT-close CLV +2.4% on 280 (beat 77%) · expected +37.42 vs actual -36.84

### EV when placed
- Under 1% · 17 bets (2 open) · 6-9 (win 40%) · ROI +35.0% · profit +9.94 · EV when placed +0.5% · CLV +0.1% on 15 closed (beat close 53%, t=0.1) · INDEPENDENT-close CLV +1.4% on 8 (beat 63%) · expected +0.05 vs actual -2.37
- 1–2% · 172 bets (33 open) · 63-75 (win 46%) · ROI -1.1% · profit -1.41 · EV when placed +1.6% · CLV +0.1% on 133 closed (beat close 56%, t=0.1) · INDEPENDENT-close CLV +2.2% on 52 (beat 69%) · expected +2.11 vs actual -1.41
- 2–3% · 490 bets (36 open) · 208-243-3 (win 46%) · ROI -4.0% · profit -19.57 · EV when placed +2.5% · CLV +0.6% on 422 closed (beat close 68%, t=1.7) · INDEPENDENT-close CLV +1.3% on 189 (beat 75%) · expected +12.48 vs actual -19.72
- 3–4% · 595 bets (33 open) · 262-297-3 (win 47%) · ROI -0.8% · profit -6.28 · EV when placed +3.5% · CLV +2.1% on 512 closed (beat close 75%, t=8.4) · INDEPENDENT-close CLV +2.7% on 213 (beat 80%) · expected +26.04 vs actual -4.93
- 4–6% · 411 bets (18 open) · 161-231-1 (win 41%) · ROI -13.9% · profit -81.21 · EV when placed +4.7% · CLV +1.5% on 335 closed (beat close 70%, t=3.6) · INDEPENDENT-close CLV +2.8% on 123 (beat 78%) · expected +27.24 vs actual -81.44
- 6% and up · 0 bets (0 open) · ROI n/a · profit +0.00 · EV when placed n/a · CLV n/a (no true close yet)
- No EV on record · 98 bets (0 open) · 48-47-3 (win 51%) · ROI +5.4% · profit +5.99 · EV when placed n/a · CLV +1.0% on 29 closed (beat close 55%, t=0.6) · no independent close

### Time before the game
- under 30 min · 143 bets (1 open) · 65-74-3 (win 47%) · ROI +0.1% · profit +0.11 · EV when placed +3.1% · CLV +3.4% on 138 closed (beat close 88%, t=13.6) · INDEPENDENT-close CLV +3.9% on 52 (beat 90%) · expected +5.42 vs actual -0.88
- 30 min-2 h · 191 bets (3 open) · 82-106 (win 44%) · ROI -9.7% · profit -23.13 · EV when placed +3.5% · CLV +2.8% on 182 closed (beat close 87%, t=12.0) · INDEPENDENT-close CLV +2.8% on 72 (beat 89%) · expected +8.52 vs actual -25.01
- 2-6 h · 380 bets (9 open) · 162-205-3 (win 44%) · ROI -6.0% · profit -27.08 · EV when placed +3.3% · CLV +2.3% on 359 closed (beat close 77%, t=9.6) · INDEPENDENT-close CLV +2.7% on 145 (beat 81%) · expected +15.24 vs actual -24.83
- 6-24 h · 586 bets (30 open) · 257-298-1 (win 46%) · ROI -2.1% · profit -15.85 · EV when placed +3.4% · CLV +0.3% on 459 closed (beat close 61%, t=0.9) · INDEPENDENT-close CLV +1.6% on 190 (beat 74%) · expected +23.95 vs actual -24.31
- 24 h or more · 421 bets (79 open) · 152-187-3 (win 45%) · ROI -4.9% · profit -20.89 · EV when placed +3.0% · CLV -0.2% on 308 closed (beat close 55%, t=-0.3) · INDEPENDENT-close CLV +1.5% on 126 (beat 65%) · expected +12.95 vs actual -30.03
- after the start · 62 bets (0 open) · 30-32 (win 48%) · ROI -11.2% · profit -5.69 · EV when placed +3.6% · CLV n/a (no true close yet) · expected +1.84 vs actual -4.80

### Liquidity
- Under $10 · 172 bets (22 open) · 73-75-1 (win 49%) · ROI +7.4% · profit +13.46 · EV when placed +3.5% · CLV +2.3% on 141 closed (beat close 77%, t=3.9) · INDEPENDENT-close CLV +2.4% on 55 (beat 82%) · expected +6.43 vs actual +13.23
- $10-25 · 81 bets (8 open) · 32-41 (win 44%) · ROI -11.2% · profit -11.09 · EV when placed +3.2% · CLV +1.9% on 71 closed (beat close 75%, t=3.1) · INDEPENDENT-close CLV +2.2% on 23 (beat 70%) · expected +3.59 vs actual -11.09
- $25-100 · 174 bets (15 open) · 71-88 (win 45%) · ROI -4.8% · profit -10.91 · EV when placed +3.1% · CLV +2.1% on 159 closed (beat close 81%, t=5.0) · INDEPENDENT-close CLV +1.8% on 89 (beat 80%) · expected +7.80 vs actual -10.91
- $100-500 · 259 bets (38 open) · 91-127-3 (win 42%) · ROI -13.0% · profit -41.30 · EV when placed +3.2% · CLV +1.1% on 205 closed (beat close 72%, t=2.4) · INDEPENDENT-close CLV +2.1% on 103 (beat 78%) · expected +11.11 vs actual -41.39
- $500 or more · 170 bets (23 open) · 54-93 (win 37%) · ROI -16.9% · profit -32.07 · EV when placed +3.4% · CLV -0.1% on 138 closed (beat close 63%, t=-0.2) · INDEPENDENT-close CLV +2.1% on 58 (beat 71%) · expected +7.24 vs actual -32.07
- Not recorded · 927 bets (16 open) · 427-478-6 (win 47%) · ROI -1.0% · profit -10.63 · EV when placed +3.3% · CLV +1.2% on 732 closed (beat close 66%, t=4.5) · INDEPENDENT-close CLV +2.4% on 257 (beat 77%) · expected +31.75 vs actual -27.63

### Odds
- Underdog (+110 to +200) · 988 bets (76 open) · 372-537-3 (win 41%) · ROI -10.2% · profit -111.10 · EV when placed +3.4% · CLV +1.5% on 803 closed (beat close 69%, t=5.8) · INDEPENDENT-close CLV +2.5% on 319 (beat 77%) · expected +37.69 vs actual -101.90
- Even money (−110 to +110) · 583 bets (35 open) · 273-272-2 (win 50%) · ROI +0.7% · profit +4.77 · EV when placed +3.1% · CLV +1.1% on 488 closed (beat close 70%, t=3.7) · INDEPENDENT-close CLV +1.6% on 196 (beat 76%) · expected +22.04 vs actual -11.89
- Favorite (−200 to −110) · 193 bets (10 open) · 95-83-5 (win 53%) · ROI +7.2% · profit +19.28 · EV when placed +3.1% · CLV +1.0% on 150 closed (beat close 72%, t=1.9) · INDEPENDENT-close CLV +2.4% on 69 (beat 81%) · expected +7.57 vs actual +9.77
- Heavy favorite (−200 or shorter) · 9 bets (0 open) · 6-3 (win 67%) · ROI -19.5% · profit -2.71 · EV when placed +3.0% · CLV -5.0% on 2 closed (beat close 0%) · no independent close · expected +0.37 vs actual -3.06
- Long shot (over +200) · 10 bets (1 open) · 2-7 (win 22%) · ROI -50.7% · profit -2.78 · EV when placed +4.3% · CLV +1.6% on 3 closed (beat close 67%, t=0.5) · INDEPENDENT-close CLV +5.0% on 1 (beat 100%) · expected +0.25 vs actual -2.78

### Scanner
- CNO · 919 bets (63 open) · 388-464-3 (win 46%) · ROI -3.4% · profit -38.54 · EV when placed +3.0% · CLV +1.0% on 766 closed (beat close 68%, t=3.6) · INDEPENDENT-close CLV +2.0% on 326 (beat 75%) · expected +34.60 vs actual -54.05
- Vigilant · 803 bets (58 open) · 330-408-7 (win 45%) · ROI -5.6% · profit -51.09 · EV when placed +3.5% · CLV +1.7% on 679 closed (beat close 71%, t=7.4) · INDEPENDENT-close CLV +2.4% on 259 (beat 79%) · expected +31.42 vs actual -52.91
- Live bids · 47 bets (0 open) · 21-26 (win 45%) · ROI -11.8% · profit -4.33 · EV when placed +3.6% · CLV n/a (no true close yet) · expected +1.35 vs actual -4.33
- Pinnodds live · 7 bets (0 open) · 3-4 (win 43%) · ROI -19.1% · profit -1.34 · EV when placed +4.3% · CLV n/a (no true close yet) · expected +0.30 vs actual -1.34
- Live tail · 4 bets (0 open) · 4-0 (win 100%) · ROI +6.3% · profit +0.25 · EV when placed +3.5% · CLV n/a (no true close yet) · expected +0.14 vs actual +0.25
- ParlayAPI · 3 bets (1 open) · 2-0 (win 100%) · ROI +125.9% · profit +2.51 · EV when placed +5.5% · CLV -10.1% on 1 closed (beat close 0%) · no independent close · expected +0.12 vs actual +2.51

### Close basis
- history:pinnacle · 569 bets (5 open) · 252-311-1 (win 45%) · ROI -5.7% · profit -40.71 · EV when placed +3.2% · CLV +2.2% on 569 closed (beat close 77%, t=9.2) · INDEPENDENT-close CLV +2.2% on 569 (beat 77%) · expected +24.30 vs actual -40.74
- No true close yet · 337 bets (107 open) · 97-128-4 (win 43%) · ROI -11.9% · profit -31.76 · EV when placed +3.3% · CLV n/a (no true close yet) · expected +6.53 vs actual -38.34
- history:novig-trades · 289 bets (0 open) · 134-153-2 (win 47%) · ROI +3.6% · profit +13.85 · EV when placed +3.1% · CLV -0.3% on 289 closed (beat close 49%, t=-0.7) · no independent close · expected +12.06 vs actual -3.42
- read:vigilant · 276 bets (8 open) · 115-152-1 (win 43%) · ROI -8.8% · profit -26.59 · EV when placed +3.5% · CLV +1.7% on 276 closed (beat close 73%, t=4.8) · no independent close · expected +10.29 vs actual -19.91
- read:cno · 242 bets (0 open) · 113-127-2 (win 47%) · ROI -3.5% · profit -12.15 · EV when placed +3.3% · CLV +0.5% on 242 closed (beat close 71%, t=0.9) · no independent close · expected +12.01 vs actual -12.27
- read:both · 54 bets (2 open) · 27-25 (win 52%) · ROI -0.5% · profit -0.30 · EV when placed +3.4% · CLV +1.7% on 54 closed (beat close 76%, t=2.4) · no independent close · expected +2.29 vs actual -0.30
- history:espn · 16 bets (0 open) · 10-6 (win 63%) · ROI +28.3% · profit +5.12 · EV when placed +2.4% · CLV +3.4% on 16 closed (beat close 81%, t=3.9) · INDEPENDENT-close CLV +3.4% on 16 (beat 81%) · expected +0.45 vs actual +5.12

### By week placed
- week of 2026-09-21 · 130 bets (0 open) · 69-61 (win 53%) · ROI +9.8% · profit +12.83 · EV when placed +2.7% · CLV +1.2% on 64 closed (beat close 59%, t=1.6) · INDEPENDENT-close CLV +3.7% on 20 (beat 85%) · expected +1.82 vs actual +6.51
- week of 2026-09-28 · 475 bets (0 open) · 213-259-3 (win 45%) · ROI -2.6% · profit -16.26 · EV when placed +3.1% · CLV +0.3% on 440 closed (beat close 61%, t=0.8) · INDEPENDENT-close CLV +1.6% on 166 (beat 70%) · expected +19.56 vs actual -30.26
- week of 2026-10-05 · 729 bets (1 open) · 331-393-3 (win 46%) · ROI -4.5% · profit -47.31 · EV when placed +3.5% · CLV +1.9% on 665 closed (beat close 74%, t=10.0) · INDEPENDENT-close CLV +2.4% on 262 (beat 82%) · expected +36.97 vs actual -46.50
- week of 2026-10-12 · 449 bets (121 open) · 135-189-4 (win 42%) · ROI -15.4% · profit -41.80 · EV when placed +3.3% · CLV +1.3% on 277 closed (beat close 74%, t=3.0) · INDEPENDENT-close CLV +2.3% on 137 (beat 74%) · expected +9.56 vs actual -39.61

## Automatic findings (closing-line value, strongest evidence first)
### Beating the close
- Sharp book = A sharp book agreed AND Time before the game = under 30 min: CLV +3.6% on 100 closed (t=13.7, beat close 91%) · ROI -4.9% · profit -6.23
- Time before the game = under 30 min: CLV +3.4% on 138 closed (t=13.6, beat close 88%) · ROI +1.6% · profit +2.75
- Type of bet = Player props AND Time before the game = under 30 min: CLV +3.8% on 98 closed (t=12.9, beat close 93%) · ROI -1.7% · profit -2.17
- Bet or bid = Bets (taker orders) AND Time before the game = under 30 min: CLV +3.5% on 111 closed (t=12.6, beat close 88%) · ROI +2.0% · profit +2.85
- Type of bet = Player props AND Time before the game = 30 min-2 h: CLV +3.1% on 135 closed (t=12.6, beat close 90%) · ROI -10.0% · profit -17.76
- Auto or manual = Auto AND Time before the game = under 30 min: CLV +3.2% on 82 closed (t=12.4, beat close 88%) · ROI +3.6% · profit +3.56
- Time before the game = 30 min-2 h: CLV +2.8% on 182 closed (t=12.0, beat close 87%) · ROI -6.6% · profit -14.99
- Sport = Hockey AND Sharp book = A sharp book agreed: CLV +2.7% on 318 closed (t=11.7, beat close 81%) · ROI -2.4% · profit -9.17
- Sport = Football AND Time before the game = under 30 min: CLV +3.5% on 72 closed (t=11.6, beat close 93%) · ROI -8.0% · profit -7.26
- Time before the game = under 30 min AND Scanner = CNO: CLV +3.8% on 75 closed (t=11.4, beat close 89%) · ROI +1.0% · profit +1.02
- Time before the game = under 30 min AND Odds = Underdog (+110 to +200): CLV +4.3% on 73 closed (t=11.2, beat close 88%) · ROI -11.6% · profit -9.65
- Sport = Hockey AND EV when placed = 3–4%: CLV +3.1% on 162 closed (t=11.0, beat close 83%) · ROI +20.3% · profit +39.37
- Sport = Hockey: CLV +2.5% on 356 closed (t=10.6, beat close 79%) · ROI -0.9% · profit -3.69
- Books behind the fair = 6-9 books AND Time before the game = 30 min-2 h: CLV +3.2% on 74 closed (t=10.5, beat close 89%) · ROI +0.1% · profit +0.14
- Type of bet = Team totals AND Books behind the fair = 10 or more books: CLV +4.0% on 38 closed (t=10.4, beat close 92%) · ROI +3.4% · profit +1.09
### Giving the close away
- Sport = Basketball AND Sharp book = A sharp book agreed: CLV -3.1% on 76 closed (t=-2.4, beat close 58%) · ROI -5.0% · profit -5.01
- Sport = Basketball AND Time before the game = 6-24 h: CLV -4.4% on 50 closed (t=-2.3, beat close 48%) · ROI -33.0% · profit -21.71
- Type of bet = Spreads AND Time before the game = 6-24 h: CLV -5.0% on 30 closed (t=-2.2, beat close 50%) · ROI -29.5% · profit -10.71
- Type of bet = Spreads AND Sport = Basketball: CLV -5.1% on 32 closed (t=-2.1, beat close 44%) · ROI -31.8% · profit -12.11
- Time before the game = 6-24 h AND Liquidity = $500 or more: CLV -3.7% on 46 closed (t=-2.1, beat close 52%) · ROI -47.4% · profit -26.29
- Type of bet = Spreads AND Odds = Even money (−110 to +110): CLV -3.1% on 51 closed (t=-2.0, beat close 47%) · ROI +9.4% · profit +5.69
- Auto or manual = Auto AND Sport = Basketball: CLV -2.4% on 79 closed (t=-2.0, beat close 61%) · ROI -13.7% · profit -14.77
- Sport = Basketball AND Books behind the fair = 6-9 books: CLV -4.0% on 34 closed (t=-1.9, beat close 59%) · ROI -27.8% · profit -13.73
- Type of bet = Spreads AND EV when placed = 1–2%: CLV -3.0% on 33 closed (t=-1.7, beat close 39%) · ROI -26.9% · profit -8.24
- Bet or bid = Bets (taker orders) AND Type of bet = Spreads: CLV -1.6% on 128 closed (t=-1.6, beat close 55%) · ROI +7.9% · profit +11.73
- Type of bet = Game totals AND Odds = Even money (−110 to +110): CLV -1.6% on 43 closed (t=-1.5, beat close 40%) · ROI +16.0% · profit +6.95
- Type of bet = Spreads: CLV -1.4% on 135 closed (t=-1.5, beat close 57%) · ROI +7.1% · profit +11.14
- Sport = Basketball AND EV when placed = 4–6%: CLV -2.9% on 39 closed (t=-1.5, beat close 59%) · ROI -32.5% · profit -19.45
- EV when placed = 1–2% AND Odds = Even money (−110 to +110): CLV -1.3% on 71 closed (t=-1.4, beat close 56%) · ROI -2.6% · profit -1.76
- EV when placed = 2–3% AND Time before the game = 6-24 h: CLV -1.1% on 102 closed (t=-1.3, beat close 54%) · ROI +6.7% · profit +7.98
(t = mean CLV over its standard error: |t| of 2+ is hard to get by luck for one group, but this scans 1474 groups, so expect some at |t| of 2-3 by chance alone: trust the ones that are large AND make sense, and that hold on `closeIndependent: true` bets.)

## Bids posted (all, filled or not)
- All bids · 22234 posted · 245 filled (1%), 218 fully · $383.22 paid · median time to first fill 94s · picked off (fair under price at the fill) 1% of 231 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- status canceled: 21205
- status expired: 794
- status filled: 218
- status refused: 16
- status lost: 1
### By kind
- Player props · 11924 posted · 174 filled (1%), 152 fully · $277.49 paid · median time to first fill 86s · picked off (fair under price at the fill) 1% of 167 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- Team totals · 8589 posted · 65 filled (1%), 61 fully · $99.22 paid · median time to first fill 133s · picked off (fair under price at the fill) 2% of 59 judged, mean fill EV +3.7% · mean EV at posting +3.8%
- 1st half / inning / set lines · 961 posted · 4 filled (0%), 4 fully · $4.87 paid · median time to first fill 106s · picked off (fair under price at the fill) 0% of 4 judged, mean fill EV +2.8% · mean EV at posting +3.1%
- Game totals · 416 posted · 1 filled (0%), 1 fully · $0.71 paid · mean EV at posting +3.3%
- Spreads · 278 posted · 0 filled (0%), 0 fully · $0.00 paid · mean EV at posting +3.0%
- Moneylines · 66 posted · 1 filled (2%), 0 fully · $0.93 paid · median time to first fill 2s · picked off (fair under price at the fill) 0% of 1 judged, mean fill EV +1.0% · mean EV at posting +2.6%
### By time before the start when posted
- under 30 min · 608 posted · 14 filled (2%), 12 fully · $14.88 paid · median time to first fill 93s · picked off (fair under price at the fill) 0% of 13 judged, mean fill EV +3.1% · mean EV at posting +3.5%
- 30 min-2 h · 1603 posted · 36 filled (2%), 32 fully · $57.10 paid · median time to first fill 91s · picked off (fair under price at the fill) 0% of 35 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- 2-6 h · 5682 posted · 81 filled (1%), 73 fully · $111.13 paid · median time to first fill 104s · picked off (fair under price at the fill) 3% of 77 judged, mean fill EV +3.3% · mean EV at posting +3.6%
- 6-24 h · 11513 posted · 112 filled (1%), 99 fully · $197.04 paid · median time to first fill 93s · picked off (fair under price at the fill) 0% of 104 judged, mean fill EV +3.6% · mean EV at posting +3.6%
- 24 h or more · 2828 posted · 2 filled (0%), 2 fully · $3.07 paid · median time to first fill 9s · picked off (fair under price at the fill) 0% of 2 judged, mean fill EV +2.8% · mean EV at posting +3.8%
### By scanner / auto
- vigilant (auto) · 22018 posted · 236 filled (1%), 211 fully · $363.82 paid · median time to first fill 102s · picked off (fair under price at the fill) 1% of 222 judged, mean fill EV +3.4% · mean EV at posting +3.6%
- cno (auto) · 216 posted · 9 filled (4%), 7 fully · $19.41 paid · median time to first fill 2s · picked off (fair under price at the fill) 0% of 9 judged, mean fill EV +3.7% · mean EV at posting +3.5%

## Data quality
- without the record as placed (older or imported bets): 519 of 1915 (27%)
- with a recorded star rating (rated live): 418 of 1915 (22%)
- with an estimated star rating: 978 of 1915 (51%)
- with no star rating possible: 519 of 1915 (27%)
- started but with no true close: 276 of 1915 (14%)
- left out of the averages as outliers: 121 of 1915 (6%)
- open: 127 of 1915 (7%)
- true closes by basis: history:pinnacle 585, history:novig-trades 306, read:vigilant 300, read:cno 251, read:both 57, history:espn 16

